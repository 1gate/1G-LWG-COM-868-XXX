#!/usr/bin/python
# -*- coding: utf-8 -*-

import time
from cisco_functions import *

# this script will run permanently
# it will update data when changing
# for instance, IP address can change in case of router restart
# or address renewal
# or the gateway can be plugged to another router port

duration_when_not_ready = 60
duration_when_ready     = 3600

while True:

    if not gateway_ready():
        print "Required information not available"
        time.sleep(duration_when_not_ready)
        continue

    # virtual mode: determine the gateway channel for comm with router
    # for all modes: retrieve ip and host information
    mode = get_mode()

    duration = duration_when_ready
    if mode == STANDALONE_MODE:
        analyze_standalone()
    else:
        print "Determine virtual channel ..."
        determine_virtual_channel()
        # if credentials are incorrect for instance, it may have failed
        if os.path.isfile(VIRTUAL_CHANNEL_FILE):
            vc = get_virtual_channel()
            log("Virtual channel is " + str(vc))
            analyze_virtual()
        else:
            duration = duration_when_not_ready

    time.sleep(duration)
