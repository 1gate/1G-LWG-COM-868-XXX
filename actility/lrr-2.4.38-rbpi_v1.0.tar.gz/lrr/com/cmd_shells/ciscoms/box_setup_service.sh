#!/bin/sh
#

exec 2> /dev/null

ROOTACT=/tmp/mdm/pktfwd/firmware
export ROOTACT

CURRENT_DIR=`dirname $0`
. $ROOTACT/lrr/com/functionsservice.sh

OPTIONS=""
LRR_DATA=$ROOTACT/usr/data/lrr
BS_DATA=$LRR_DATA/box_setup
NAME="box_setup"
SERVICE="$NAME.sh"
SERVICE_RUNDIR="$ROOTACT/lrr/com/cmd_shells/ciscoms/"
PIDFILE=$BS_DATA/$NAME.pid
STOPFILE=$BS_DATA/stop

usage() {
    echo "Usage: $NAME [<options>] {start|stop|status|restart}"
    echo "  Where options are:"
    echo "   -h|--help    Print this help message"
}


preStart() {
        mkdir -p $BS_DATA
}

serviceCommand() {
        echo "$ROOTACT/lrr/com/cmd_shells/ciscoms/$SERVICE "$OPTIONS
}

stopService() {
        BS_PIDS=$(pidof $SERVICE)
        [ -n "$BS_PIDS" ] && kill -TERM $BS_PIDS
}

abortService() {
        BS_PIDS=$(pidof $SERVICE)
        [ -n "$BS_PIDS" ] && kill -KILL $BS_PIDS
}

handleParams $*
