#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import pexpect
import sys
import sched
import time
import os
import subprocess
from glob import glob
from datetime import datetime

DEBUG = False
DEBUG_DIALOG = False

#
# WARNING: works only since firmware >= 2.0.31
#

ROOTACT = '/tmp/mdm/pktfwd/firmware'
CREDENTIALS = ROOTACT + '/usr/etc/lrr/credentials.txt'
INTERFACES = ROOTACT + '/usr/etc/lrr/interfaces.config'
HOSTS_IP_STATUS = '/var/run/hosts_ip_status'

# definition of flag files: created at startup
# these files are created by Cisco service
STANDALONE_FILE = "/var/run/standalone"
VIRTUAL_FILE = "/var/run/virtual"
SERVER_IP_FILE = "/var/run/svr_ip"

# this file is created by our service
VIRTUAL_CHANNEL_FILE = "/var/run/virtual_channel"

# definition of gateway mode
UNKNOWN_MODE    = 0
STANDALONE_MODE = 1
VIRTUAL_MODE    = 2


def log(msg):

    if DEBUG:
        print str(datetime.now()) + " " + msg


# 
# in standalone mode: connection to gateway (IXM)
# - secret
# - user
# - password
# 
# in virtual mode: connection to router (IR8x9)
# - user
# - password
#
def load_credentials():

    log("load_credentials ...")

    with open(CREDENTIALS) as f:
        content = f.readlines()
    content = [x.strip() for x in content]

    mode = get_mode()
    if mode == STANDALONE_MODE:
        if len(content) < 3:
            print 'Problem with credentials in file!'
            exit(1)
        adminsecpassword = content[0]
        username = content[1]
        password = content[2]
        log("- admin: " + adminsecpassword)
        log("- user:  " + username)
        log("- pwd:   " + password)
    else:
        if len(content) < 2:
            print 'Problem with credentials in file!'
            exit(1)
        adminsecpassword = ""
        username = content[0]
        password = content[1]
        log("- user:  " + username)
        log("- pwd:   " + password)

    return (adminsecpassword, username, password)


def spawn_command(cmd):

    log("  spawn command: " + cmd)
    p = pexpect.spawn(cmd)
    if DEBUG_DIALOG:
        p.logfile = sys.stdout
    return p


#
# use to check that all needed functions are available
# on the gateway after booting
def gateway_ready():

    mode = get_mode()

    if mode == UNKNOWN_MODE:
        return False

    if mode == STANDALONE_MODE:
        return True

    # virtual mode: svr_ip file takes time to become
    # available (about 1mn after boot end)
    if os.path.isfile(SERVER_IP_FILE):
        return True
    return False


def get_server_ip():

    log("get_server_ip")

    try:
        with open(SERVER_IP_FILE, "r") as f:
            ip = f.readline()
            log("  Server IP address: " + ip)
        return ip

    except Exception, e:
        log("Exception while reading " + SERVER_IP_FILE + ": " + str(e))


def determine_virtual_channel():

    log("determine_virtual_channel")

    local_sn = os.popen("getsn").read()
    local_sn = local_sn.replace('\n','')
    log("  local S/N: " + local_sn)

    try:

        p = execute_logging()

        # request the list of all virtual interfaces

        execute_command(p, "show ip interface brief | include LPWA")
        output = p.before
        output = output.replace('\r','')

        # a line looks like (1st line is not included in output: just for explanation)
        # Interface                  IP-Address      OK? Method Status                Protocol
        # Virtual-LPWA4              unassigned      YES unset  up                    up
        # note: ignore the 1st line, this is the echo of the "show ip" command

        nb = 0

        for l in output.splitlines():
            nb += 1
            if nb == 1:
                continue
            # keep only the number at the end of Virtual-LPWA"
            virtual_channel = l.split()[0].replace('Virtual-LPWA','')
            # retrieve the S/N of the connected gateway
            execute_command(p, "show virtual-lpwa " + str(virtual_channel) + " modem info | include ^SerialNumber")
            sn_output = p.before
            sn_output = sn_output.replace('\r','')

            # 3 lines at least: echo of command + SN + beginning of prompt
            # line looks like:
            # show virtual-lpwa ...
            # SerialNumber : FOC21028RE6
            # IR829
            try:
                if len(sn_output) >= 3:
                    line = sn_output.splitlines()[1]
                    sn = line.split()[2]
                    log("  SN of channel " + str(virtual_channel) +": " + sn)
                    if sn == local_sn:
                        log("  virtual channel found: " + str(virtual_channel))
                        # create a file to store the virtual channel
                        f = open(VIRTUAL_CHANNEL_FILE, "w")
                        f.write(str(virtual_channel) + "\n")
                        f.close()
                        # no need to continue
                        return
            except:
                # cannot retrieve needed info from output
                # likely virtual channel is defined but down (no gateway)
                pass

        log("Virtual channel for S/N: " + local_sn + " not found")

    except Exception, e:
        log("determine_virtual_channel exception " + str(e))


def get_virtual_channel():

    log("get_virtual_channel")

    try:
        with open(VIRTUAL_CHANNEL_FILE, "r") as f:
            vc = f.readline()
        log("  virtual channel: " + str(vc))
        return vc.replace('\n','')

    except Exception, e:
        log("Exception while reading " + VIRTUAL_CHANNEL_FILE + ": " + str(e))


#
# update lrr.ini if [versions] exists
#
# [versions]
#   hardware_version=<>
#   os_version=<>
#
def update_lrr_ini(cisco_mode, cisco_version):

    lrr_ini = ROOTACT + '/usr/etc/lrr/lrr.ini'
    lrr_ini_r = open(lrr_ini, 'r')
    lrr_ini_l = lrr_ini_r.readlines()
    lrr_ini_r.close()

    for line in lrr_ini_l:
        if '[versions]' in line:

            # Insert the cisco mode
            subprocess.call(['sed', '-i',
                            "/hardware_version.*/c\    hardware_version=" + cisco_mode,
                            lrr_ini])

            # insert the FW version
            subprocess.call(['sed', '-i',
                            "/os_version.*/c\    os_version=" + cisco_version + '',
                            lrr_ini])


#
# update interfaces
#
# ETHIPADDR=<ip>
# ETHNETMASK=<netmask"
#

def update_interfaces(ip, netmask_value):

    log("update interfaces: " + INTERFACES)
    log(ip + " " + netmask_value)

    subprocess.call(['sed', '-i',
                     "/ETHIPADDR.*/c\ETHIPADDR="
                     + ip + '', INTERFACES])
    subprocess.call(['sed', '-i',
                     "/ETHNETMASK.*/c\ETHNETMASK="
                     + netmask_value + '', INTERFACES])

def update_host_status(val):
    with open(HOSTS_IP_STATUS, 'w+') as f:
        f.write(val + '\n')
        f.close()

def update_host_ip(address_config):

    log("update host ip")

    host_ip_tmp = '0'
    host_ip = \
        re.search(r'.*Internet address is (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*'
                  , address_config)
    #Get netmask
    netmask = \
        re.search(r'.*Netmask is (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*'
                  , address_config)
    try:
        ip = host_ip.group(1)
        netmask_value = netmask.group(1)
    except Exception, e:
        ip = 0
        netmask_value = 0
    if ip != host_ip_tmp:
        update_host_status(str(ip))
        host_ip_tmp = ip

    #Write IP adress to interfaces.config
    update_interfaces(ip, netmask_value)


def update_dhcp(str):

    subprocess.call(['sed', '-i',
                     '/ETHDHCP.*/c\ETHDHCP=' + str,
                     INTERFACES])


def analyze_standalone():

    log("analyse_standalone")

    p = execute_logging()

    execute_command(p, 'show running-config')
    run_config = p.before
    # VLANs could be unconfigured
    vlan_ip = re.search(r'.*Vlan (\d{1,4}).*', run_config)
    log("vlan_ip: " + str(vlan_ip))
    try:

        # Check if DHCP is enabled
        is_dhcp = re.search(r'dhcp', run_config)
        if is_dhcp:
            log("DHCP")
            update_dhcp("yes")
        else:
            log("STATIC")
            update_dhcp("no")

        # try to get number of vlan
        vlan = vlan_ip.group(1)

        # vlan number is present, parse host's ip from vlan configuration
        execute_command(p, 'show ip interface Vlan ' + str(vlan))
        address_config = p.before

    except Exception, e:

        log("EXCEPTION!!!")

        # number of vlan does not exists
        # now, try with FastEthernet 0/1
        execute_command(p, 'show ip interface FastEthernet 0/1')
        address_config = p.before

    version = 0
    try:
        # Run the 'show inventory' command and retrieve the ImageVer value and insert into lrr.ini
        execute_command(p, 'show inventory')
        inventory = p.before
        cisco_fw = \
            re.search(r"(?:(ImageVer.*: ))(\d+.\d+.\d+)",
                      inventory)
        version = cisco_fw.group(2)
        execute_command(p, 'request shell exit', wait_for_prompt=False)

        update_lrr_ini("cisco_standalone", version)
        update_host_ip(address_config)

    except Exception, e:
        print e
        execute_command(p, 'request shell exit', wait_for_prompt=False)



def analyze_virtual():

    log("analyse_virtual")

    ip = get_server_ip()

    p = execute_logging()

    try:
        vc = get_virtual_channel()
        execute_command(p, 'show virtual-lpwa ' + str(vc) + ' modem info')
        inventory = p.before
        cisco_fw = \
            re.search(r"(?:(ImageVer.*: ))(\d+.\d+.\d+)",
                      inventory)
        version = cisco_fw.group(2)
        execute_command(p, 'exit', wait_for_prompt=False)

        # no easy to way to retrieve the netmask on the router side
        # TEMP: retrieve the netmask of the local eth0 interface: should be the same than the router
        # TODO: retrieve the netmask on the router side
        netmask = os.popen("ifconfig eth0 | awk -F: '/Mask:/{print $4}'").read()

        update_lrr_ini("cisco_router", version)
        update_dhcp("yes")
        update_interfaces(ip, netmask)
        update_host_status(ip)

    except Exception, e:
        print e
        execute_command(p, 'exit', wait_for_prompt=False)


#
# COMMON FUNCTIONS
#


def get_mode():

    log("get_mode")

    if os.path.isfile(STANDALONE_FILE):
        log("  -> STANDALONE mode")
        return STANDALONE_MODE
    elif os.path.isfile(VIRTUAL_FILE):
        log("  -> VIRTUAL mode")
        return VIRTUAL_MODE
    else:
        log("  ->UNKNOWN mode")
        return UNKNOWN_MODE


def execute_logging():

    adminsecpassword, username, password = load_credentials()

    mode = get_mode()

    log("execute logging")

    if mode == UNKNOWN_MODE:
        return -1

    while True:

        if mode == STANDALONE_MODE:
            ip = "10.0.3.1"

        else:
            ip = get_server_ip()

        cmd = \
            'ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ' \
            + username + '@' + ip
        log("  cmd: " + cmd)

        p = spawn_command(cmd)
        p.expect('[pP]assword:')
        p.sendline(password)

        if mode == STANDALONE_MODE:
            p.expect('Press RETURN to get started')
            p.sendline('\n')
            p.expect('Press RETURN to get started')
            p.sendline('\n')

        reply = p.expect(['>', '#'])
        if reply == 0:
            p.sendline('enable')
            p.expect('Password:')
            p.sendline(adminsecpassword)
            p.expect('#')

        log("  end of execute_logging: prompt detected")

        return p

def execute_command(p, cmd, wait_for_prompt=True):

    try:

        log("execute command: " + cmd)
        p.sendline(cmd)
        if wait_for_prompt:
            # as the output could be used to display results for suplog,
            # looking also for "Gateway#" will prevent "Gateway" to be part of the output
            p.expect(["Gateway#", "#"])
            log("command executed: prompt detected")

    except Exception, e:
        log("Exception while executing command " + cmd + ": " + str(e))

def not_standalone_error(msg = None):

    log("not_standalone_error")

    line = "Not in standalone mode: "
    if msg is not None and msg != "":
        line += msg
    else:
        line += "command"
    line += " not implemented"
    print line
