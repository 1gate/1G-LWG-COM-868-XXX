#!/usr/bin/python
# -*- coding: utf-8 -*-

import pexpect
import sys
import os

from cisco_functions import *

mode = get_mode()

if mode != STANDALONE_MODE:
    not_standalone_error("Firmare installation")
    sys.exit(1)

p = execute_logging()

execute_command(p, 'configure terminal')
execute_command(p, 'container copy ' + sys.argv[1] + ' flash:')
execute_command(p, 'exit')
execute_command(p, 'request shell exit', wait_for_prompt=False)

os.remove(sys.argv[1])
filename = sys.argv[1].split('/')[-1]

p = execute_logging()

execute_command(p, 'archive download-sw firmware /normal /save-reload flash:'
           + filename)
execute_command(p, 'request shell exit', wait_for_prompt=False)
