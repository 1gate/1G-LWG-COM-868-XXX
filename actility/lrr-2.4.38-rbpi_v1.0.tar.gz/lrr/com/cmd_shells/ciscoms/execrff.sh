#!/usr/bin/python
# -*- coding: utf-8 -*-

###########################################################################

import os
import re
import pexpect
import sys
import time
from datetime import datetime
from subprocess import call

from cisco_functions import *


try:

    mode = get_mode()

    if mode != STANDALONE_MODE:
        not_standalone_error("restoring backup")
        sys.exit(1)

    p = execute_logging()

    execute_command(p, 'copy flash:backup_config running-config')
    execute_command(p, 'copy running-config startup-config')

    exit(0)

except Exception, e:

    print 'Restoring backup failed, exception: ' + str(e)
    exit(1)
