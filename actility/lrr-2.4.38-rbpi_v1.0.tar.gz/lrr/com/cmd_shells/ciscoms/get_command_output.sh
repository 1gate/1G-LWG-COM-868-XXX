#!/usr/bin/python
# -*- coding: utf-8 -*-

###########################################################################
# get_command_outout.sh
#
# this script is about executing a command needing to retrieve outputs
# (mainly for suplog)
#
# 1: expected outputs (generic command, not the actual gateway command)
#
###########################################################################

import re
import pexpect
import sys
import time
import os

from cisco_functions import *


# in case the actual command is different in standalone and in router mode
# 0: standalone mode
# 1: router mode
command_list= {
    "ipsec_show":
         ["show ipsec log", "show virtual-lpwa %vc% modem log name ipsec"]
    ,
    "ipsec_listcerts":
         ["show ipsec certs", None]
    ,
    "ipsec_statusall":
         ["show ipsec status detail", None]
    ,
    "ipsec_status":
        ["show ipsec status info", "show virtual-lpwa %vc% modem ipsec status"]
    }

#
# MAIN
#
if len(sys.argv) <= 1:
    print "no command to execute"
    sys.exit(1)


p = None

try:

    mode = get_mode()

    if mode == UNKNOWN_MODE:
        print "Cannot access Cisco privileged account: gateway mode unknown"
        sys.exit(1)

    index = 0
    vc = 0
    if mode != STANDALONE_MODE:
        index = 1
        vc = get_virtual_channel()

    option = sys.argv[1]
    cmd = command_list[option][index]
    if cmd is None:
        log("option " + option + " not implemented for this gateway mode")
        sys.exit(1)

    for i in range(2,len(sys.argv)):
        cmd = cmd + " " + sys.argv[i]
    cmd = cmd.replace('%vc%', str(vc))

    p = execute_logging()
    execute_command(p, cmd)

    output = p.before
    output = output.replace('\r','')
    # ignore the 1st line: contains the echo of the command
    first = True
    for line in output.split('\n'):
        if first:
            first = False
        else:
            print line

    p.sendline('exit')

except Exception, e:

    if p is not None:
        p.sendline('exit')
        log("exit sent on exception: " + str(e))
