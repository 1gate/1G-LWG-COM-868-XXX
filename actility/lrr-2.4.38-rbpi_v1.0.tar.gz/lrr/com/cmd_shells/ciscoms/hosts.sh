#!/bin/sh
#
# checking if specific hosts file corresponds to /etc/hosts
#

ROOTACT=/tmp/mdm/pktfwd/firmware
export ROOTACT

LRR_DATA=$ROOTACT/usr/data/lrr
SERVICE=$(basename "$0")
PIDFILE=$LRR_DATA/hosts.pid
counter=0

while true
do
        sleep 5
	echo "SERVICE: $SERVICE"
        diff $ROOTACT/usr/etc/lrr/customer_hosts /etc/hosts
        if [ $? -ne 0 ]
        then
                cp $ROOTACT/usr/etc/lrr/customer_hosts /etc/hosts
                counter=0
        else
                counter=$((counter+1))
                if [[ "$counter" -eq 15 ]]; then
                        SERVICE_PID=$(cat $PIDFILE | cut -d "|" -f1)
                        SELF_PID=$(ps -ef | grep "$SERVICE" | awk '{print $1}' | head -1)
                        kill -9 $SERVICE_PID
                        kill -9 $SELF_PID
                fi
        fi
done

