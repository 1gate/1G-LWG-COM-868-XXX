#!/bin/sh
#
# copying customer specific hosts to /etc/hosts

exec 2> /dev/null

ROOTACT=/tmp/mdm/pktfwd/firmware
export ROOTACT

CURRENT_DIR=`dirname $0`
. $ROOTACT/lrr/com/functionsservice.sh

OPTIONS=""
HOSTS_DATA=$ROOTACT/usr/data/lrr/hosts
SERVICE="hosts.sh"
SERVICE_RUNDIR="$ROOTACT/lrr/com/cmd_shells/ciscoms/"
PIDFILE=$HOSTS_DATA/hosts.pid
STOPFILE=$HOSTS_DATA/stop

usage() {
    echo "Usage: hosts [<options>] {start|stop|status|restart}"
    echo "  Where options are:"
    echo "   -h|--help    Print this help message"
}


preStart() {
        mkdir -p $HOSTS_DATA
}

serviceCommand() {
        echo "./hosts.sh "$OPTIONS
}

stopService() {
	hosts_PIDS=$(pidof hosts.sh)
        [ -n "$hosts_PIDS" ] && kill -TERM $hosts_PIDS
}

abortService() {
	hosts_PIDS=$(pidof hosts.sh)
        [ -n "$hosts_PIDS" ] && kill -KILL $hosts_PIDS
}



handleParams $*

exit $?
