#!/bin/bash
#
#       Analyze a /etc/network/interfaces, ntp.conf and vpn.cfg files
#
#       The format expected for /etc/network/interfaces is the following:
#...
#ETHERNET=yes
#ETHDHCP=yes
#ETHIPADDR=192.168.4.155
#ETHNETMASK=255.255.255.0
#ETHBROADCAST=192.168.4.255
#ETHGATEWAY=192.168.4.1
#DNSSERVER1=212.30.96.123
#DNSSERVER2=213.203.124.147
#...
#
#
#       The format expected for ntp.conf is:
#...
#server pool.ntp.org
#...
#
# Note: the lines that start with 'server 127.127' are ignored
#
#
#       The format expected for vpn.cfg is:
#...
#SRV=195.65.47.47
#...
#

TMPINTER="/tmp/_lrrinter"
TMPNTP="/tmp/_lrrntp"
DHCP=0
IP=""
MASK=""
DNS=""
GW=""
NTP=""

use()
{
        echo "netconfig [-i <interfacesfile>] [-n <ntpfile>] [--dhcp 0|1 --address <ipaddr> --dns <dnslist> --ntp <ntpaddr> --mask <mask>] --gw <gatewayaddr>]"
        echo "  options -i and -n are useless for fcpico gateway"
        exit 1
}

finished()
{
        echo "DHCP=$DHCP"
        echo "IP=$IP"
        echo "MASK=$MASK"
        echo "GW=$GW"
        echo "DNS=$DNS"
        echo "NTP=$NTP"

        exit 0
}

printconf()
{
        if [ $DHCP = 1 ]
        then
                echo "iface eth0 inet dhcp"
                echo
                return
        fi

        echo "iface eth0 inet static"
        echo "  address $IP"
        echo "  netmask $MASK"
        [ ! -z "$GW" ] && echo "        gateway $GW"
        echo "  dns-nameservers $DNS"
}

readntp()
{
        file="$1"

        if [ ! -f "$file" ]
        then
                echo "Can't read file '$file' !"
                return
        fi

        lst=$(grep "^server" $file | grep -v "server 127.127" | awk '{ print $2 }')
        NTP=$(echo $lst)
}

readinter()
{
        file="$1"

        if [ ! -f "$file" ]
        then
                echo "Can't read file '$file' !"
                return
        fi

        . $file

        if [ "$ETHDHCP" = "yes" ]
        then
                DHCP="1"
        else
                DHCP="0"
        fi

        IP="$ETHIPADDR"
        MASK="$ETHNETMASK"
        GW="$ETHGATEWAY"
        DNS="$DNSSERVER1 $DNSSERVER2"
}

calcbroadcast()
{
        addr="$1"
        mask="$2"

        [ -z "$addr" ] && return
        [ -z "$mask" ] && return

        # remove .
        addrnp=${addr//./ }
        masknp="${mask//./ }"

        # treat each part
        i=1
        while [ $i -le 4 ]
        do
                # get one part
                a=$(echo $addrnp | awk -v N=$i '{ print $N }')
                m=$(echo $masknp | awk -v N=$i '{ print $N }')

                # check part is not empty
                [ -z "$a" -o -z "$m" ] && return

                # get negative mask
                nm=$((~$m & 255))

                # calculate and set broadcast address
                [ $i -ne 1 ] && bcast="$bcast."
                bcast="$bcast$(($a | $nm))"
                i=$(($i + 1))
        done
        echo "$bcast"
}

writeinter()
{
        file="$1"
        fileout="$2"
        [ -z "$fileout" ] && fileout="$TMPINTER"

        if [ ! -f "$file" ]
        then
                echo "Can't read file '$file' !"
                return
        fi

        # save original file
        [ ! -f "$file.original" ] && cp "$file" "$file.original"

        if [ "$DHCP" = "0" ]
        then
                DHCPSTR="no"
        else
                DHCPSTR="yes"
        fi

        if [ ! -z "$DNS" ]
        then
                set $DNS
                dns1=$1
                dns2=$2
        fi

        while read ln
        do
                case $ln in
                        ETHERNET=*)     echo "ETHERNET=yes"
                                ;;
                        ETHDHCP=*)      echo "ETHDHCP=$DHCPSTR"
                                ;;
                        ETHIPADDR=*)    echo "ETHIPADDR=$IP"
                                ;;
                        ETHNETMASK=*)   echo "ETHNETMASK=$MASK"
                                ;;
                        ETHGATEWAY=*)   echo "ETHGATEWAY=$GW"
                                ;;
                        ETHBROADCAST=*) echo "ETHBROADCAST=$(calcbroadcast $IP $MASK)"
                                ;;
                        DNSSERVER1=*)   echo "DNSSERVER1=$dns1"
                                ;;
                        DNSSERVER2=*)   echo "DNSSERVER2=$dns2"
                                ;;
                        *)      echo "$ln"
                                ;;
                esac
        done < $file > $fileout
        [ -z "$AUTOTEST" ] && mv $fileout $file
}


writentp()
{
        savlocstr="# ACTILITY SUPLOG: insert servers here"
        file="$1"
        fileout="$2"
        [ -z "$fileout" ] && fileout="$TMPNTP"

        if [ ! -f "$file" ]
        then
                echo "Can't read file '$file' !"
                return
        fi

        added="0"
        while read ln
        do
                case $ln in
                        "server 127.127"*)
                                echo "$ln"
                                ;;

                        $savlocstr)
                                echo "$savlocstr"
                                added="1"
                                for srv in $NTP
                                do
                                        echo "server $srv"
                                done
                                ;;

                        server*)
                                [ "$added" = "1" ] && continue
                                echo "$savlocstr"
                                added="1"
                                [ -z "$NTP" ] && continue

                                for srv in $NTP
                                do
                                        echo "server $srv"
                                done
                                ;;

                        *)
                                echo "$ln"
                                ;;
                esac
        done < $file > $fileout
        [ -z "$AUTOTEST" ] && mv $fileout $file
}

mode="read"
while [ $# -gt 0 ]
do
        case $1 in
                --dhcp) shift
                        DHCP=$1
                        mode="write"
                        ;;
                --address)      shift
                        IP="$1"
                        mode="write"
                        ;;
                --gw)   shift
                        GW="$1"
                        mode="write"
                        ;;
                --dns)  shift
                        DNS="$1"
                        mode="write"
                        ;;
                --ntp)  shift
                        NTP="$1"
                        mode="write"
                        ;;
                --mask) shift
                        MASK="$1"
                        mode="write"
                        ;;
                -i)     shift
                        interfile="$1"
                        ;;
                -n)     shift
                        ntpfile="$1"
                        ;;
                -a)     NODATE=1
                        ;;
                -v)     VERBOSE=1
                        ;;
                --interout) shift
                        interfout="$1"
                        ;;
                --ntpout) shift
                        ntpfout="$1"
                        ;;
                --autotest) AUTOTEST="yes"
                        ;;
                -*)     use
                        ;;
        esac
        shift
done

if [ "$mode" = "read" ]
then
        readinter $interfile
        readntp $ntpfile
        finished
else
        # all parameters for the configuration are mandatory
        if [ "$DHCP" = "0" ]
        then
                if [ -z "$IP" ]
                then
                        echo "Error: ip address mandatory"
                        use
                fi
                if [ -z "$DNS" ]
                then
                        echo "Error: dns address mandatory"
                        use
                fi
                if [ -z "$MASK" ]
                then
                        echo "Error: address mask mandatory"
                        use
                fi
                if [ -z "$GW" ]
                then
                        echo "Error: gateway address mandatory"
                        use
                fi

        fi
        if [ -z "$NTP" ]
        then
                echo "Error: ntp address mandatory"
                use
        fi

        writeinter $interfile $interfout
        writentp $ntpfile $ntpfout

        #Write network confiurations to host
        [ -z "$AUTOTEST" ] && /tmp/mdm/pktfwd/firmware/lrr/com/cmd_shells/ciscoms/WriteNetConfHost.sh
fi
