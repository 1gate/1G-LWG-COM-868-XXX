#!/bin/sh

ROOTACT=/tmp/mdm/pktfwd/firmware
export ROOTACT

DELAY="15"
if      [ "$1" != "" ]
then
        DELAY=$1
fi


if [ ! -f $ROOTACT/usr/etc/lrr/customer_hosts ]; then
	echo "You are missing $ROOTACT/usr/etc/lrr/customer_hosts file. Your /etc/hosts data may be lost. "
fi

cp /etc/hosts $ROOTACT/usr/etc/lrr/customer_hosts


echo    "lrr will be rebooted in $DELAY sec"
nohup $ROOTACT/lrr/com/cmd_shells/ciscoms/reboot_pending.sh $DELAY > /dev/null 2>&1 &
exit 0
