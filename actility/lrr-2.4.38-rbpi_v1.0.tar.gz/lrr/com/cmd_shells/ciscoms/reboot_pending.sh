#!/usr/bin/python
# -*- coding: utf-8 -*-

###########################################################################
# Name of script : reboot_pending.sh
# usage : to reboot the gw from lxc container
# usage example : ./reboot_pending.sh -> it is called from reboot.sh script
# warnings : May loose the connectivity as the gw is reloaded
###########################################################################

import re
import pexpect
import sys
import time
import os

from cisco_functions import *

mode = get_mode()

if mode == UNKNOWN_MODE:
    sys.exit(1)

try:

    p = execute_logging()

    if mode == STANDALONE_MODE:

        execute_command(p, 'copy running-config startup-config')
        p.sendline('reload')
        p.expect('Proceed with reload')
        p.sendline('y')
        p.sendline('y')


    else:

        vc = get_virtual_channel()
        execute_command(p, 'virtual-lpwa ' + str(vc) + ' modem reboot')
        p.sendline('exit')

    print 'Reload started'

except Exception, e:

    print 'Reload failed, exception: ' + str(e)
