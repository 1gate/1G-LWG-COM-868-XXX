#!/bin/sh
#
#	Execute a radio scan
#	
. ${ROOTACT}/lrr/com/cmd_shells/common_scan_fct.sh

SCAN=${ROOTACT}/lrr/util_spectral_scan/util_spectral_scan

parse_arguments "$@"

init_lrr_env

get_ism_band
get_range_parameters

#give time to lrr process to stop radio thread
wait_for_radio_stop

check_scan_tool

LOGFILE=rfscanv1.log
init_scan

scan_with_rfreq

#sleep again if scan util exit immediatly
wait_for_scan_end

upload_csv
exit 0
