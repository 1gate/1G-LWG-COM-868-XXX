#!/usr/bin/python
# -*- coding: utf-8 -*-

###########################################################################

import os
import re
import pexpect
import sys
import time
from datetime import datetime
from subprocess import call

from cisco_functions import *

try:

    mode = get_mode()

    if mode != STANDALONE_MODE:
        not_standalone_error("Backup")

    p = execute_logging()

    execute_command(p, "copy running-config startup-config")
    execute_command(p, "copy running-config flash:backup_config")


    micro = datetime.utcnow().strftime('%f')[:-5]
    datestring = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.'
            + micro + '+00:00')

    f = open(ROOTACT + '/usr/etc/lrr/saverff_done', 'w+')
    version = open(ROOTACT + '/lrr/Version', 'r+')
    version_line = version.readline()

    f.write('RFFVERSION=' + version_line + '\n')
    f.write('RFFDATE=' + datestring + '\n')

    version.close()
    f.close()
    exit(0)

except Exception, e:

    print 'Backup failed, exception: ' + str(e)
    exit(1)
