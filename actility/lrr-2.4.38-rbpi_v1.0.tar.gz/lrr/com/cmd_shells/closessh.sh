#!/bin/sh

#
#

killall sshpass.x

