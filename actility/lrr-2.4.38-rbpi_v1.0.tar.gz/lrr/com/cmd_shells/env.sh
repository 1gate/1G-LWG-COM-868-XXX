env | sort
exit 0
