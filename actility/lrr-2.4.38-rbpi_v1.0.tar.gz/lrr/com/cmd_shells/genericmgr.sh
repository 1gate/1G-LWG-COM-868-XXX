#!/bin/sh

# Use: genericmgr.sh
#
#	Call a manager 

MGRNAME="$1"
CONFDEFAULT=$ROOTACT/lrr/config/$MGRNAME.ini
CONFCUSTOM=$ROOTACT/usr/etc/lrr/$MGRNAME.ini

[ -z "$MGRNAME" ] && exit 1
shift

if [ "$1" == "--test" ]
then
	TEST="test"
	shift
fi

if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

mgr=$(getIniConf $CONFCUSTOM $MGRNAME$TEST cmd)
[ $? = 0 ] && mgr=$(getIniConf $CONFDEFAULT $MGRNAME$TEST cmd)

if [ -z "$mgr" ]
then
	if [ ! -f "$ROOTACT/lrr/$MGRNAME/$MGRNAME$TEST.sh" ]
	then
		echo "No $MGRNAME$TEST defined !" 1>&2
		exit 1
	else
		echo "No $MGRNAME$TEST defined, use default one found '$ROOTACT/lrr/$MGRNAME/$MGRNAME$TEST.sh'" 1>&2
		mgr="$ROOTACT/lrr/$MGRNAME/$MGRNAME$TEST.sh"
	fi
fi

# eval environment variables 
#echo "mgr='$mgr'"
eval mgr="$mgr"
if [ ! -f "$mgr" ]
then
	echo "Can't find $MGRNAME '$mgr' !"
	exit 1
fi

$mgr $*
