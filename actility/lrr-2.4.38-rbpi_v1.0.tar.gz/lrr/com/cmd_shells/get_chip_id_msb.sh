#!/bin/sh

export PATH=$PATH:$ROOTACT/lrr/com/

. ${ROOTACT}/lrr/com/_functions.sh

chip_id_path="/usr/bin/chip_id"

get_spidevice() {

    # Note:
    # likely to retrieve fcloc-specific spi device without managing the section, "device" was duplicated
    # as "spidevice" for fcloc
    # this function then looks first for "spidevice" as it was designed specifically for rfscanv1
    # and may be not equal to "device" in some configs (or "device" may be missing)
    # then look for "device" if "spidevice" is not present
    lrr_list="$ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    for lrr_f in $lrr_list; do
        SPIDEVICE=$(getIniConf "$lrr_f" "$SYSTEM\/spidevice:0" "spidevice")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
        SPIDEVICE=$(getIniConf "$lrr_f" "$SYSTEM\/spidevice:0" "device")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
    done
}

get_spidevice

if [ ! -f ${chip_id_path} ]; then
	#test if chip_id is stored somewhere else, it's usually stored in /opt/kona64-pkt-forwarder/dvt/chip_id for Kona64
	chip_id_path=$(find ${ROOTACT} -name chip_id | grep chip_id)
	if [ ! -f ${chip_id_path} ]; then
		echo "unidentified"
		exit 1
	fi
fi
#run chip_id and select the LSB / MSB values, returns the version
chip_id_msb=$(eval $chip_id_path -d $SPIDEVICE | grep "MSB" | cut -d " " -f 4| tr '[:lower:]' '[:upper:]')
if [ -z ${chip_id_msb} ]
then
    echo "unidentified"
else
    echo ${chip_id_msb}
fi
