#!/bin/sh

export PATH=$PATH:$ROOTACT/lrr/com/

. ${ROOTACT}/lrr/com/_functions.sh

#copy
get_spidevice() {

    # Note:
    # likely to retrieve fcloc-specific spi device without managing the section, "device" was duplicated
    # as "spidevice" for fcloc
    # this function then looks first for "spidevice" as it was designed specifically for rfscanv1
    # and may be not equal to "device" in some configs (or "device" may be missing)
    # then look for "device" if "spidevice" is not present
    lrr_list="$ROOTACT/usr/etc/lrr/lrr.ini ${ROOTACT}/lrr/config/lrr.ini"
    for lrr_f in $lrr_list; do
        SPIDEVICE=$(getIniConf "$lrr_f" "$SYSTEM\/spidevice:0" "spidevice")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
        SPIDEVICE=$(getIniConf "$lrr_f" "$SYSTEM\/spidevice:0" "device")
        if [ ! -z "$SPIDEVICE" ]; then
            return
        fi
    done
}

get_spidevice

#This will call the get_fpga_version.x binary and format the returned version

if [ ! -f $ROOTACT/lrr/com/get_fpga_version.x ]; then
	echo "get_fpga_version.x not found, cannot read FPGA version"
	exit 1
fi

#run FPGA binary
get_fpga_version.x -d ${SPIDEVICE} | grep 'FPGA Version' | sed 's/FPGA Version://g'
