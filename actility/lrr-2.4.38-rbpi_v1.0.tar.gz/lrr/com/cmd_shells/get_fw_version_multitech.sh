#!/bin/sh

#This will parse the Multitech mlinux-version file and format the returned version

cat /etc/mlinux-version | grep mLinux | sed 's/mLinux //'
