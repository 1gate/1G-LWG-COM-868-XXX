#!/bin/sh

#This will parse the Tektelic system_version file and format the returned version

system_version | grep Release | awk '{print $2}'

