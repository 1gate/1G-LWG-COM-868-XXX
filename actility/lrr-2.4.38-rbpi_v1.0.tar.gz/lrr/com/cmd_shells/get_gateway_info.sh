#!/bin/sh
#
#	Get gateway information
#	This script can return various information:
#	* FPGA Version : FPGA version flashed on the HW
#	* HAL Version  : current HAL version
#	* FW Version   : FW (or BSP) version - manufacturer dependent
#	* HW ID        : HW ID of the Gateway (HW revision)
#   * Serial       : Serial ID of the Gateway
#	* SKU          : Stock Keeping Unit if made available by the manufacturer
#	* LRRID        : Current gateway LRRID
#   * LRR Version  : Current running LRR version
#   * OS Version   : Linux Kernel version running on the GW
#   * Chip ID MSB  : MSB ID of the GW used to get the AES Key from Semtech
#   * Chip ID LSB  : LSB ID of the GW used to get the AES Key from Semtech

# script file(s) to be sourced
. ${ROOTACT}/lrr/com/_functions.sh


echo "Updating ${ROOTACT}/usr/etc/lrr/versions.ini file"

# Path to the versions.ini that will be created and populated with all the retrieved information
CUSTOM_INI_FILE=${ROOTACT}/usr/etc/lrr/versions.ini

# Custom script directory, to be used for development and testing only as it's overriding other script directories
CUSTOM_SCRIPT_DIR=$ROOTACT/usr/etc/lrr/cmd_shells
# Common system script directory, to be used to deploy Gateway specific scripts
COMMON_SYSTEM_SCRIPT_DIR=$ROOTACT/lrr/com/cmd_shells/${SYSTEM}
# Common script directory, to be used to store generic Gateway scripts
COMMON_SCRIPT_DIR=$ROOTACT/lrr/com/cmd_shells


# This is a list of directories where script can/should be found, in the right order
#
# First, the LRR will look for the script in the CUSTOM_SCRIPT_DIR
# Then it will look for the script in COMMON_SYSTEM_SCRIPT_DIR
# Then it will eventually look for the script in the COMMON_SCRIPT_DIR
# If it was not found in one of those directories, it's assumed that the script doesn't exist
#
SCRIPT_DIR_SEARCH_LIST="$CUSTOM_SCRIPT_DIR $COMMON_SYSTEM_SCRIPT_DIR $COMMON_SCRIPT_DIR"

execute_script() {

	SCRIPT=$1

	for dir in $SCRIPT_DIR_SEARCH_LIST
    do
        if [ -f ${dir}/${SCRIPT} ]
        then
            #execute script
            ${dir}/${SCRIPT}
            return 1
        fi
    done
	echo "unidentified"
}


update_version_ini_file() {

    #empty the versions.ini file
    true > $CUSTOM_INI_FILE
    echo "[versions]" >> $CUSTOM_INI_FILE
    echo "lrr_version=$lrrversion" >> $CUSTOM_INI_FILE
    echo "lrrid=$lrrid" >> $CUSTOM_INI_FILE
    echo "hal_version=$hal" >> $CUSTOM_INI_FILE
    echo "fpga_version=$fpga" >> $CUSTOM_INI_FILE
    echo "semtech_ref_design=$refdesign" >> $CUSTOM_INI_FILE
    echo "firmware_version=$fwver" >> $CUSTOM_INI_FILE
    echo "os_version=$osver" >> $CUSTOM_INI_FILE
    echo "hardware_version=$hwid" >> $CUSTOM_INI_FILE
    echo "serial_number=$serial" >> $CUSTOM_INI_FILE
    echo "sku=$sku" >> $CUSTOM_INI_FILE
    echo "chip_id_lsb=$chip_lsb" >> $CUSTOM_INI_FILE
    echo "chip_id_msb=$chip_msb" >> $CUSTOM_INI_FILE
    #for future info to be fetched
    #echo "xxx=$xxx" >> $CUSTOM_INI_FILE
}


# get_fpga_version.sh
#
# NOTE FOR INTEGRATORS : To be developped as every GW has a different device path for the Semtech LoRa device
# Will call the get_fpga_version.x binary, which will in turn return the current FPGA version
# For Ref Design V1.0, get_fpag_version.x will not return anything as there is no FPGA (0)
# For Ref Design V1.5, get_fpga_version.x requires no input parameter
# For Ref Design V2.1, get_fpga_version.x requires the SPI Device as parameter (ex: "get_fpga_version.x -d /dev/spidev0.0")
#
# Input parameter : none
# Output parameter : FPGA version (numerical version, no "v"), exemple : 28
#
# This script will return the FPGA version of the LoRa module

fpga=$(execute_script get_fpga_version.sh)

# get_hal_version.sh
#
# NOTE FOR INTEGRATORS : Generic function, this should not have to be developped
#
# Get HAL version will probe the LoRa chip to return the HAL version
# Input parameter : none
# Output parameter : HAL version (numerical version, example: 4.1.3)
#
# This script will call the get_hal_version.x binary, which will in turn return the HAL version, to be parsed if necessary

hal=$(execute_script get_hal_version.sh)

# get_fw_version.sh
#
# NOTE FOR INTEGRATORS : To be developped as every GW has a different way to report FW version
#
# Input parameter : none
# Output parameter : FW version of the gateway
#
# This script will return the FW version of the gateway

fwver=$(execute_script get_fw_version.sh)

# get_hwid.sh
#
# NOTE FOR INTEGRATORS : To be developped as every GW has a different way to report Hardware ID, if available
#
# Input parameter : none
# Output parameter : Hardware ID of the gateway
#
# This script will return the HW ID of the gateway

hwid=$(execute_script get_hwid.sh)

# get_os_version.sh
#
# NOTE FOR INTEGRATORS : This is a standard Linux command (uname -r) is called, this should be generic and not to be updated
#    unless the value in versions.ini is wrong
#
# Input parameter : none
# Output parameter : Linux version running on the GW
#
# This script will return the Linux version running on the gateway

osver=$(execute_script get_os_version.sh)


# get_serial.sh
#
# NOTE FOR INTEGRATORS : To be developped as every GW has a different way to report Serial number, if available
#
# Input parameter : none
# Output parameter : Serial number of the gateway
#
# This script will return the Serial number of the gateway

serial=$(execute_script get_serial.sh)

# get_sku.sh
#
# NOTE FOR INTEGRATORS : To be developped as every GW has a different way to report SKU, if available
#
# Input parameter : none
# Output parameter : Stock Keeping Unit of the gateway
#
# This script will return the SKU of the gateway

sku=$(execute_script get_sku.sh)


# get_lrrid.sh
#
# NOTE FOR INTEGRATORS : Generic function, this should not have to be developped
#
#	Usually the LRRID is the 8 last digits of the MAC address of main ethernet interface
# 	In case the unicity of the MAC address cannot be certified, implement a new method based
#	on a unique metric (Serial number or Hardware ID of the GW)
#
# Input parameter : none
# Output parameter : LRRID of the gateway
#
# This script will return the LRRID of the gateway

lrrid=$(execute_script getlrrid.sh | cut -d "=" -f 2)


# get_lrr_version.sh
#
# NOTE FOR INTEGRATORS : Generic function, this should not have to be developped
#
# Input parameter : none
# Output parameter : LRR Version of the gateway
#
# This script will return the LRRID of the gateway

lrrversion=$(execute_script get_lrr_version.sh)


# get_chip_id_lsb.sh
#
# NOTE FOR INTEGRATORS : Generic function, this should not have to be developped, unless working on a Non Semtech Reference Design
#
# Input parameter : none
# Output parameter : LSB Chip ID of the gateway
#
# This script will return the LSB Chip ID of the gateway, needed to get the AES Key from Semtech in order to use the Geolocation feature

chip_lsb=$(execute_script get_chip_id_lsb.sh)


# get_chip_id_msb.sh
#
# NOTE FOR INTEGRATORS : Generic function, this should not have to be developped, unless working on a Non Semtech Reference Design
#
# Input parameter : none
# Output parameter : MSB Chip ID of the gateway
#
# This script will return the MSB Chip ID of the gateway, needed to get the AES Key from Semtech in order to use the Geolocation feature

chip_msb=$(execute_script get_chip_id_msb.sh)

# get_semtech_refdesign.sh
#
# NOTE FOR INTEGRATORS : To be developped for every GW
#
# Input parameter : none
# Output parameter : Semtech Reference Design of the gateway's LoRa module
#
# This script will return the Semtech Reference Design of the gateway's LoRa module

refdesign=$(execute_script get_semtech_refdesign.sh)


# PROTOTYPE to add a new information field in the versions.ini file
#
# get_xxx.sh
#
# NOTE FOR INTEGRATORS :
#
# Input parameters :
# Output parameters :
#
#
#
# xxx=$(execute_script get_xxx.sh)

#now that we got every piece of information, populate the versions.ini file
update_version_ini_file

echo "${ROOTACT}/usr/etc/lrr/versions.ini file updated"
