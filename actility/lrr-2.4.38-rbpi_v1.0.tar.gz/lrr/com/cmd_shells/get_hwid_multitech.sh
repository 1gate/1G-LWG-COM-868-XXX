#!/bin/sh

#This will call the mts-io-sysfs binary that is used to retrieve specific Multitech information

mts-io-sysfs show hw-version
