#!/bin/sh

sqlite3 "/tmp/commissioning.db" "SELECT Module_Revision FROM Configuration"
