#!/bin/sh

uname -r
