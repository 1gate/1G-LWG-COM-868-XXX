#!/bin/sh

mts-io-sysfs show device-id
