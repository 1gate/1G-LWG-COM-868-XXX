#!/bin/sh

sqlite3 "/tmp/commissioning.db" "SELECT Module_Serial_Number FROM Configuration"
