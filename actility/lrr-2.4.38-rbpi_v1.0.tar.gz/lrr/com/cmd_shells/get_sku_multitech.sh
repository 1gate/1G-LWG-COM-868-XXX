#!/bin/sh

mts-io-sysfs show product-id
