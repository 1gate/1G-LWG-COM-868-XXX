#!/bin/sh

sqlite3 "/tmp/commissioning.db" "SELECT Product_Code FROM Configuration"
