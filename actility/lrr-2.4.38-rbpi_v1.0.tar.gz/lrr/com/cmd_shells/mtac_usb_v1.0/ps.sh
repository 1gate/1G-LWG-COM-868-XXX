#!/bin/sh

ps ax
exit $?
