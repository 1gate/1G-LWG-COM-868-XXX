#!/bin/sh

${ROOTACT}/lrr/com/cmd_shells/get_hwid_multitech.sh
