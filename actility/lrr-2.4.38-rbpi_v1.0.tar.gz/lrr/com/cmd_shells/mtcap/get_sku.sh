#!/bin/sh

${ROOTACT}/lrr/com/cmd_shells/get_sku_multitech.sh
