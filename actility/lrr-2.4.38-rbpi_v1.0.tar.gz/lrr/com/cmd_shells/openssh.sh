#!/bin/sh

#
#

# PATH for sshpass command
PATH=.:$PATH

cd $ROOTACT/lrr/com
#killall sshpass.x

[ -z "$SSHUSERSUPPORT" ] && SSHUSERSUPPORT=support
[ -z "$SSHPASSSUPPORT" ] && SSHPASSSUPPORT=support
[ -z "$SSHHOSTSUPPORT" ] && SSHHOSTSUPPORT=support1.actility.com
[ -z "$SSHPORTSUPPORT" ] && SSHPORTSUPPORT=81

[ -z "$BKPSSHUSERSUPPORT" ] && BKPSSHUSERSUPPORT=support
[ -z "$BKPSSHPASSSUPPORT" ] && BKPSSHPASSSUPPORT=support
[ -z "$BKPSSHHOSTSUPPORT" ] && BKPSSHHOSTSUPPORT=support2.actility.com
[ -z "$BKPSSHPORTSUPPORT" ] && BKPSSHPORTSUPPORT=81

[ -z "$FTPUSERSUPPORT" ] && FTPUSERSUPPORT=ftp
[ -z "$FTPPASSSUPPORT" ] && FTPPASSSUPPORT=
[ -z "$FTPHOSTSUPPORT" ] && FTPHOSTSUPPORT=support1.actility.com
[ -z "$FTPPORTSUPPORT" ] && FTPPORTSUPPORT=21

[ -z "$BKPFTPUSERSUPPORT" ] && BKPFTPUSERSUPPORT=ftp
[ -z "$BKPFTPPASSSUPPORT" ] && BKPFTPPASSSUPPORT=
[ -z "$BKPFTPHOSTSUPPORT" ] && BKPFTPHOSTSUPPORT=support2.actility.com
[ -z "$BKPFTPPORTSUPPORT" ] && BKPFTPPORTSUPPORT=21


REQUIREDPORT=2009
BREAKCNX=3600
AUTOSTART="0"

#-o StrictHostKeyChecking is not available on wirmav2
#-Itmt is only available on wirmav2 but it seems it does not work

#echo	"SYSTEM=$SYSTEM"

case	$SYSTEM in
	wirmav2)
		SSHOPT="-y -N -I600"
	;;
	fcloc|fclamp|fcpico|tektelic|tek_macro16|tek_micro8|tek_dish64)
		SSHOPT="-y -N -y -y"
	;;
	*)
		SSHOPT="-y -N -o StrictHostKeyChecking=no"
	;;
esac

while	[ $# -gt 0 ]
do
	case	$1 in 
		-a)
			shift
			AUTOSTART="1"
		;;
		-P)
			shift
			REQUIREDPORT="${1}"
			shift
		;;
		-I)
			shift
			BREAKCNX="${1}"
			shift
		;;
		-K)
			shift
			rm ${HOME}/.ssh/known_hosts
		;;
		-A)
			shift
			SSHHOSTSUPPORT="${1}"
			shift
		;;
		-D)
			shift
			SSHPORTSUPPORT="${1}"
			shift
		;;
		-U)
			shift
			SSHUSERSUPPORT="${1}"
			shift
		;;
		-W)
			shift
			SSHPASSSUPPORT="${1}"
			shift
		;;
		*)
			shift
		;;
	esac
done

if [ -f ${ROOTACT}/lrr/com/_functions.sh ]; then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

KillChild()
{
	ppid="$1"
	[ -z "$ppid" ] && return
	lstpid=$(grep "^PPid:.*$ppid"  /proc/*/status | sed "s?^/proc/??" | sed "s?/.*??" 2>/dev/null)
	echo "child $lstpid"
	kill $lstpid 2> /dev/null
}

if [ "$AUTOSTART" = "1" ]
then
	FILEDST=/tmp/autorevssh.txt
	rm ${FILEDST} 2> /dev/null
	FILESRC=AUTOREVSSH_LRR/${LRRID}
	echo "lrr_DownloadFromRemote -u ${FTPUSERSUPPORT} -w ZZZZZZZZ -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILEDST} -r ${FILESRC}"
	lrr_DownloadFromRemote -u ${FTPUSERSUPPORT} -w ${FTPPASSSUPPORT} -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILEDST} -r ${FILESRC}

	if [ $? = "0" -a -s "$FILEDST" ]
	then
		REQUIREDPORT=$(cat $FILEDST)
		echo	"support provides auto reverse ssh port ${REQUIREDPORT}"
	else
		echo	"support does not provide auto reverse ssh port"
		FTPUSERSUPPORT=${BKPFTPUSERSUPPORT}
		FTPPASSSUPPORT=${BKPFTPPASSSUPPORT}
		FTPHOSTSUPPORT=${BKPFTPHOSTSUPPORT}
		FTPPORTSUPPORT=${BKPFTPPORTSUPPORT}

		rm ${FILEDST} 2> /dev/null
		FILESRC=AUTOREVSSH_LRR/${LRRID}
		echo "lrr_DownloadFromRemote -u ${FTPUSERSUPPORT} -w ZZZZZZZZ -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILEDST} -r ${FILESRC}"
		lrr_DownloadFromRemote -u ${FTPUSERSUPPORT} -w ${FTPPASSSUPPORT} -a ${FTPHOSTSUPPORT} -p ${FTPPORTSUPPORT} -l ${FILEDST} -r ${FILESRC}
		if [ $? = "0" -a -s "$FILEDST" ]
		then
			REQUIREDPORT=$(cat $FILEDST)
			echo	"support bkp provides auto reverse ssh port ${REQUIREDPORT}"
		else
			echo	"support bkp does not provide auto reverse ssh port"
		fi
	fi
fi


ACCOUNT="${SSHUSERSUPPORT}@${SSHHOSTSUPPORT}"
$ROOTACT/lrr/com/ipvxchk.x -6 "${SSHHOSTSUPPORT}"
if	[ $? = "0" ]
then
	REVERSE="[${SSHHOSTSUPPORT}]:${REQUIREDPORT}:[::1]:22"
else
	REVERSE="${SSHHOSTSUPPORT}:${REQUIREDPORT}:localhost:22"
fi

# -e option of sshpass
SSHPASS=${SSHPASSSUPPORT}
export SSHPASS

# the space (' ') between -R and "${REVERSE}" is mandatory !!!!

echo sshpass.x -e ssh ${SSHOPT} -p${SSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}"
sshpass.x -e ssh ${SSHOPT} -p${SSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}" &
bkgpid=$!
echo	"pidssh $bkgpid remoteport ${REQUIREDPORT}"
BKPTRIED="false"
while	[ $BREAKCNX -gt 0 ]
do
	kill -0 $bkgpid
	if	[ $? != "0" ]
	then
		if [ "$BKPTRIED" = "false" ]; then
			# Try opening SSH session to alternative Support server
			ACCOUNT="${BKPSSHUSERSUPPORT}@${BKPSSHHOSTSUPPORT}"
			REVERSE="${BKPSSHHOSTSUPPORT}:${REQUIREDPORT}:localhost:22"
			SSHPASS=${BKPSSHPASSSUPPORT}
			export SSHPASS
			echo sshpass.x -e ssh ${SSHOPT} -p${BKPSSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}"
			sshpass.x -e ssh ${SSHOPT} -p${BKPSSHPORTSUPPORT} -R "${REVERSE}" "${ACCOUNT}" &
			bkgpid=$!
			BKPTRIED="true"
		else
			exit	1
		fi
	fi
#	echo	"pidssh $bkgpid still present"
	sleep	1
	BREAKCNX=$(expr $BREAKCNX - 1)
done
[ "$SYSTEM" = "wirmaar" -o "$SYSTEM" = "ciscoms" -o "$SYSTEM" = "fclamp" ] && KillChild $bkgpid
kill $bkgpid
exit 0
