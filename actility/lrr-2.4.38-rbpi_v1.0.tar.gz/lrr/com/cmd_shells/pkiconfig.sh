#!/bin/bash
#
#	Analyze vpn.cfg file
#
#	The format expected for vpn.cfg is:
#...
#PLATFORM=195.65.47.47
#SRV=195.65.47.47
#SRV=195.65.47.47
#...
#

MOREINI="$ROOTACT/lrr/moreini/moreini.x"
LRRCFG="$ROOTACT/usr/etc/lrr/lrr.ini"
TMPKEY="/tmp/_lrrkey"
KEYPF=""
KEYOPE=""
KEYSRV=""

if [ -f ${ROOTACT}/usr/etc/lrr/_parameters.sh ]; then
	. ${ROOTACT}/usr/etc/lrr/_parameters.sh
fi

use()
{
	echo "pkiconfig -k <keyinstfile> [--pf <keyplatform> --ope <keyoperator> --keysrv <keyserver> --lrcsrv <lrcserver --sshsrv <sshserver> --ftpsrv <ftpserver> --supsrv <supportserver>]"
	exit 1
}

finished()
{
	echo "KEYPF=$KEYPF"
	echo "KEYOPE=$KEYOPE"
	echo "KEYSRV=$KEYSRV"
	echo LRCSRV=$LRCSRV
	echo SSHSRV=$SSHSRV
	echo FTPSRV=$FTPSRV
	echo SUPSRV=$SUPSRV

	exit 0
}

readkey()
{
	if [ ! -f "$1" ]
	then
		echo "File '$1' not found ! >&2"
		return
	fi
	KEYPF=$(grep "^PLATFORM=" $1 | awk -F '=' '{ print $2 }')
	KEYOPE=$(grep "^OPERATOR=" $1 | awk -F '=' '{ print $2 }')
	KEYSRV=$(grep "^SRV=" $1 | awk -F '=' '{ print $2 }')
}

readlrr()
{
	grepstr="support_.__addr=\|support_.__ftpaddr=\|laplrc_.__addr=\|download_.__ftpaddr="
	res=$($MOREINI -t $LRRCFG -r | grep "$grepstr")
	[ ! -z "$res" ] && eval "$res"

	LRCSRV="${laplrc_0__addr} ${laplrc_1__addr}"
	SSHSRV="${support_0__addr} ${support_1__addr}"
	FTPSRV="${download_0__ftpaddr} ${download_1__ftpaddr}"
	SUPSRV="${support_0__ftpaddr} ${support_1__ftpaddr}"
}

writelrr()
{
	{
	set $LRCSRV
	nblrc=$#
	[ $nblrc -gt 2 ] && nblrc=2
	echo "[lrr]"
	echo "	nblrc=$nblrc"
	echo "[laplrc:0]"
	echo "	addr=$1"
	echo "[laplrc:1]"
	echo "	addr=$2"

	if [ "$SYSTEM" = "fcpico" ]; then
		#set nvram parameters needed for the GW Internet LED connection indicator
		nvram set lrr_pri_serv_addr=$1
		nvram set lrr_sec_serv_addr=$2
	fi

	set $FTPSRV
	echo "[download:0]"
	echo "	ftpaddr=$1"
	echo "[download:1]"
	echo "	ftpaddr=$2"

	set $SUPSRV
	sup1="$1"
	sup2="$2"

	set $SSHSRV
	echo "[support:0]"
	echo "	addr=$1"
	echo "	ftpaddr=$sup1"
	echo "[support:1]"
	echo "	addr=$2"
	echo "	ftpaddr=$sup2"

	} > $TMPKEY
	$MOREINI -t $LRRCFG -a $TMPKEY -y
}

writekey()
{
	keyf="$1"
	keyfout="$2"

	if [ ! -f "$keyf" ]
	then
		echo "File '$keyf' not found !"
		return
	fi

	cat $keyf |
		sed "s/^SRV=.*/SRV=$KEYSRV/" |
		sed "s/^OPERATOR=.*/OPERATOR=$KEYOPE/" |
		sed "s/^PLATFORM=.*/PLATFORM=$KEYPF/" > $TMPKEY
	# save file if same file for input and output and if .sav doesn't exist
	[ "$keyf" = "$keyfout" -a ! -f "$keyf.sav" ] && mv $keyf $keyf.sav
	cp $TMPKEY $keyfout
}

mode="read"
while [ $# -gt 0 ]
do
	case $1 in
		--pf)	shift
			KEYPF="$1"
			mode="write"
			;;
		--ope)	shift
			KEYOPE="$1"
			mode="write"
			;;
		--keysrv)	shift
			KEYSRV="$1"
			mode="write"
			;;
		--lrcsrv)	shift
			LRCSRV="$1"
			mode="write"
			;;
		--sshsrv)	shift
			SSHSRV="$1"
			mode="write"
			;;
		--ftpsrv)	shift
			FTPSRV="$1"
			mode="write"
			;;
		--supsrv)	shift
			SUPSRV="$1"
			mode="write"
			;;
		-k)	shift
			keyfile="$1"
			[ -z "$keyfout" ] && keyfout="$1"
			;;
		-a)	NODATE=1
			;;
		-v)	VERBOSE=1
			;;
		--keyout) shift
			keyfout="$1"
			;;
		-*)	use
			;;
	esac
	shift
done

if [ -z "$keyfile" ]
then
	echo "Error option -k mandatory"
	use
fi

if [ "$mode" = "read" ]
then
	readkey $keyfile
	readlrr
	finished
else
	# all parameters for the configuration are mandatory
	if [ -z "$KEYPF" ]
	then
		echo "Error: key-installer platform mandatory"
		use
	fi
	if [ -z "$KEYOPE" ]
	then
		echo "Error: key-installer operator mandatory"
		use
	fi
	if [ -z "$KEYSRV" ]
	then
		echo "Error: key-installer server mandatory"
		use
	fi
	if [ -z "$LRCSRV" ]
	then
		echo "Error: LRC server mandatory"
		use
	fi
	if [ -z "$SSHSRV" ]
	then
		echo "Error: SSH server mandatory"
		use
	fi
	if [ -z "$FTPSRV" ]
	then
		echo "Error: ftp server mandatory"
		use
	fi
	if [ -z "$SUPSRV" ]
	then
		echo "Error: support server mandatory"
		use
	fi

	writekey $keyfile $keyfout
	writelrr
fi
