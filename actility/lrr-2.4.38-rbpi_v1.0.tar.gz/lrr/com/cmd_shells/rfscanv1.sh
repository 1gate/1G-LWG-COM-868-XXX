#!/bin/sh
#
#	Execute a radio scan
#	
. ${ROOTACT}/lrr/com/cmd_shells/common_scan_fct.sh

SCAN=${ROOTACT}/lrr/util_spectral_scan/util_spectral_scan

parse_arguments "$@"

init_lrr_env

get_ism_band
get_range_parameters

# gateway-specific checking

if [ "$LRRSYSTEM" = "fcloc" ]; then
    # check FGPA/HAL compatibility.
    # also check ISM band support.
    # exit if not supported.
    FPGA_VER=`${ROOTACT}/lrr/com/cmd_shells/${LRRSYSTEM}/util_gw_revision -f`
    check_fcloc_compatibility
fi

#give time to lrr process to stop radio thread
wait_for_radio_stop

check_scan_tool

LOGFILE=rfscanv1.log
if	[ "$FORCE" = "0" -a "$LRRSYSTEM" = "wirmav2" ]
then
	LORABOARD=$(get_version | grep LORABOARD_)
	if	[ -z "$LORABOARD" ]
	then
		echo "cannot detect if required hardware is present, try rfscanv0"
		SCAN=${ROOTACT}/lrr/util_rssi_histogram/util_rssi_histogram
        check_scan_tool
		LOGFILE=rfscanv0.log
	fi
#	TODO more checks on hardware are required
#	eval $LORABOARD ... check type / version ...
fi

init_scan
SCANOPT=""
if [ "$LRRSYSTEM" = "wirmana" ]; then
    # take 50 mn instead of 3 mn if -n option not set
    # note: Kerlink binary is klk_spectral_scan renamed to util_spectral_scan"
    SCANOPT="-n 4096 -O rssi_histogram.csv"
    scan_simple
elif [ "$LRRSYSTEM" = "mtac_v1.5" -o "$LRRSYSTEM" = "mtac_refresh_v1.5" -o "$LRRSYSTEM" = "mtcdt_ip67" \
    -o "$LRRSYSTEM" = "mtcap" -o "$LRRSYSTEM" = "mtcdt_ip67_v2.1" -o "$LRRSYSTEM" = "gemtek" -o "$LRRSYSTEM" = "tracknet" ]; then
    scan_simple
elif [ "$LRRSYSTEM" = "tek_macro16" -o "$LRRSYSTEM" = "tek_micro8"  -o "$LRRSYSTEM" = "tek_dish64" -o "$LRRSYSTEM" = "tektelic" ]; then
    scan_with_tektelic
elif [ "$LRRSYSTEM" = "fcloc" ]; then
    if [ "$FPGA_VER" = "v61" ]; then
        scan_with_rfreq
    else
        scan_with_band
    fi
else
    scan_with_rfreq
fi

#sleep again if scan util exit immediatly
wait_for_scan_end

upload_csv
exit 0
