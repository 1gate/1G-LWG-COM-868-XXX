#!/bin/sh

file="$1"
line_nb="$2"


if [ ! -z $2 -a $2 -ge 0 2>/dev/null ]
then
#    echo "custom tail with $2 line(s)"
    line_nb="$2"
else
    line_nb=50
fi


if [ -z $file ]
then
    exit 1
fi

if [ -f $file ]
then
    tail -n$line_nb $file
    exit $?
fi

if [ -f $ROOTACT/$file ]
then
    tail -n$line_nb $ROOTACT/$file
    exit $?
fi

if [ -f $ROOTACT/var/log/lrr/$file ]
then
    tail -n$line_nb $ROOTACT/var/log/lrr/$file
    exit $?
fi

