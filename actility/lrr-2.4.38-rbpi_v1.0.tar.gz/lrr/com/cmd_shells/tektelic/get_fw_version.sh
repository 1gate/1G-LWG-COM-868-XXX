#!/bin/sh

${ROOTACT}/lrr/com/cmd_shells/get_fw_version_tektelic.sh

