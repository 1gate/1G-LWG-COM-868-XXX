#!/bin/sh

${ROOTACT}/lrr/com/cmd_shells/get_serial_tektelic.sh
