#!/bin/sh

${ROOTACT}/lrr/com/shells/getid.sh

exit 0
