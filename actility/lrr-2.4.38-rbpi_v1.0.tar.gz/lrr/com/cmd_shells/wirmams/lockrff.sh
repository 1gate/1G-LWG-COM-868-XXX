#!/bin/sh

touch $ROOTACT/usr/etc/lrr/execrff_locked
exit $?
