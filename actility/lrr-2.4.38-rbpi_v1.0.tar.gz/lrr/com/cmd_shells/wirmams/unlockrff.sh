#!/bin/sh

rm $ROOTACT/usr/etc/lrr/execrff_locked
exit $?
