#!/bin/sh

/etc/rcU.d/S89lrrfirewall stop
exit $?
