#!/bin/sh

/etc/rcU.d/S89lrrfirewall start
exit $?
