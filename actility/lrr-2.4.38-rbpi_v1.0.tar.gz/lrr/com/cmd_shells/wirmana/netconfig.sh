#!/bin/bash
#
#	Analyze a /etc/network/connman/lan.config, ntp.conf and vpn.cfg files
#
#	The format expected for /etc/network/connman/lan.config is the following:
#...
#ETHERNET=yes
#ETHDHCP=yes
#ETHIPADDR=192.168.4.155
#ETHNETMASK=255.255.255.0
#ETHBROADCAST=192.168.4.255
#ETHGATEWAY=192.168.4.1
#DNSSERVER1=212.30.96.123
#DNSSERVER2=213.203.124.147
#...
#
#
# 	The format expected for ntp.conf is:
#...
#server pool.ntp.org
#...
#
# Note: the lines that start with 'server 127.127' are ignored
#
#
#	The format expected for vpn.cfg is:
#...
#SRV=a-slrc1-eu.thingpark.com
#PLATFORM=Actility-eu
#OPERATOR=actility-tpe-ope
#...
#

TMPINTER="/tmp/_lrrinter"
TMPNTP="/tmp/_lrrntp"
DHCP=0
IP=""
MASK=""
DNS=""
GW=""
NTP=""

use()
{
	echo "netconfig [-i <interfacesfile>] [-n <ntpfile>] [--dhcp 0|1 --address <ipaddr> --dns <dnslist> --ntp <ntpaddr> --mask <mask>] --gw <gatewayaddr>]"
	echo "  options -i and -n are useless for fcpico gateway"
	exit 1
}

finished()
{
	echo "DHCP=$DHCP"
	echo "IP=$IP"
	echo "MASK=$MASK"
	echo "GW=$GW"
	echo "DNS=$DNS"
	echo "NTP=$NTP"

	exit 0
}

printconf()
{
	if [ $DHCP = 1 ]
	then
		echo "iface eth0 inet dhcp"
		echo
		return
	fi

	echo "iface eth0 inet static"
	echo "	address $IP"
	echo "	netmask $MASK"
	[ ! -z "$GW" ] && echo "	gateway $GW"
	echo "	dns-nameservers $DNS"
}

readntp()
{
	file="$1"

	if [ ! -f "$file" ]
	then
		echo "Can't read file '$file' !"
		return
	fi

	lst=$(grep "^server" $file | grep -v "server 127.127" | awk '{ print $2 }')
	NTP=$(echo $lst)
}

readinter()
{
	file="$1"

	if [ ! -f "$file" ]
	then
		echo "Can't read file '$file' !"
		return
	fi

	res=$(grep "^IPv4" $file)
	[ -z "$res" ] && return

	set $res

	if [ "$3" = "dhcp" ]
	then
		DHCP="1"
		IP=""
		MASK=""
		GW=""
	else
		DHCP="0"
		IP=$(echo $3 | awk -F / '{ print $1 }')
		MASK=$(echo $3 | awk -F / '{ print $2 }')
		MASK=$(num2mask $MASK)
		GW=$(echo $3 | awk -F / '{ print $3 }')
	fi

	DNS=$(grep "^Nameservers" $file | sed "s/.*=[ ]//" | sed "s/,/ /g")
}

mask2num()
{
	m=$1
	if [ -z "$m" ]
	then
		echo "0"
		return
	fi

	v1=$(echo $m | awk -F . '{ print $1 }')
	v2=$(echo $m | awk -F . '{ print $2 }')
	v3=$(echo $m | awk -F . '{ print $3 }')
	v4=$(echo $m | awk -F . '{ print $4 }')
	v=$(((v1 << 24) + (v2 << 16) + (v3 << 8) + v4))
	i=32
	res=0
	while [ $i -gt 0 ]
	do
		[ $((v & 1 )) -eq 1 ] && break
		v=$((v >> 1))
		i=$((i - 1))
	done
	echo "$i"
}


num2mask()
{
        n=$1
	if [ -z "$n" -o $n -lt 0 -o $n -gt 32 ]
	then
		echo "0.0.0.0"
		return
	fi

        i=0
        v=0
	res=""
        while [ $i -lt 32 ]
        do
		v=$((v << 1))
                if [ $n -gt 0 ]
                then
                        n=$((n - 1))
			v=$((v += 1))
                fi
                i=$((i + 1))
		if [ $((i % 8)) -eq 0 ]
		then
			[ ! -z "$res" ] && res="$res."
			res="$res$v"
			v=0
		fi
        done
	echo "$res"
}

writeinter()
{
	file="$1"
	fileout="$2"
	[ -z "$fileout" ] && fileout="$TMPINTER"

	if [ ! -f "$file" ]
	then
		echo "Can't read file '$file' !"
		return
	fi

	# save original file
	[ ! -f "$file.original" ] && cp "$file" "$file.original"

	if [ "$DHCP" = "0" ]
	then
		IPV4LN="IPv4 = $IP/$(mask2num $MASK)/$GW"
	else
		IPV4LN="IPv4 = dhcp"
	fi

	if [ ! -z "$DNS" ]
	then
		DNSLN="Nameservers = $(echo $DNS | sed 's/  */,/g')"
	fi

echo "DHCP=$DHCP"
	if [ -z "$DNS" -o "$DHCP" -ne "0" ]
	then
		# replace IPv4 line and remove Nameservers line
		cat $file | sed "s?^IPv4.*?$IPV4LN?" | sed "/^Nameservers.*/d" > $fileout
	else
		# check if 'Nameservers' line present
		# remove Nameservers line and then replace IPv4 line with IPv4 and Nameservers lines
		cat $file | sed "/^Nameservers.*/d" | sed "s?^IPv4.*?$IPV4LN\n$DNSLN?" > $fileout

	fi
	[ -z "$AUTOTEST" ] && mv $fileout $file
}


writentp()
{
	savlocstr="# ACTILITY SUPLOG: insert servers here"
	file="$1"
	fileout="$2"
	[ -z "$fileout" ] && fileout="$TMPNTP"

	if [ ! -f "$file" ]
	then
		echo "Can't read file '$file' !"
		return
	fi

	added="0"
	while read ln
	do
		case $ln in
			"server 127.127"*)
				echo "$ln"
				;;

			$savlocstr)
				echo "$savlocstr"
				added="1"
				for srv in $NTP
				do
					echo "server $srv"
				done
				;;

			server*)
				[ "$added" = "1" ] && continue	
				echo "$savlocstr"
				added="1"
				[ -z "$NTP" ] && continue

				for srv in $NTP
				do
					echo "server $srv minpoll 16 maxpoll 17"
				done
				;;

			*)
				echo "$ln"
				;;
		esac
	done < $file > $fileout
	[ -z "$AUTOTEST" ] && cat $fileout > $file	# mv impossible, fs read-only
}

mode="read"
while [ $# -gt 0 ]
do
	case $1 in
		--dhcp)	shift
			DHCP=$1
			mode="write"
			;;
		--address)	shift
			IP="$1"
			mode="write"
			;;
		--gw)	shift
			GW="$1"
			mode="write"
			;;
		--dns)	shift
			DNS="$1"
			mode="write"
			;;
		--ntp)	shift
			NTP="$1"
			mode="write"
			;;
		--mask)	shift
			MASK="$1"
			mode="write"
			;;
		-i)	shift
			interfile="$1"
			;;
		-n)	shift
			ntpfile="$1"
			;;
		-a)	NODATE=1
			;;
		-v)	VERBOSE=1
			;;
		--interout) shift
			interfout="$1"
			;;
		--ntpout) shift
			ntpfout="$1"
			;;
		--autotest) AUTOTEST="yes"
			;;
		-*)	use
			;;
	esac
	shift
done

if [ "$mode" = "read" ]
then
	readinter $interfile
	readntp $ntpfile
	finished
else
	# all parameters for the configuration are mandatory
	if [ "$DHCP" = "0" ]
	then
		if [ -z "$IP" ]
		then
			echo "Error: ip address mandatory"
			use
		fi
#		if [ -z "$DNS" ]
#		then
#			echo "Error: dns address mandatory"
#			use
#		fi
		if [ -z "$MASK" ]
		then
			echo "Error: address mask mandatory"
			use
		fi
		if [ -z "$GW" ]
		then
			echo "Error: gateway address mandatory"
			use
		fi
		
	fi
	if [ -z "$NTP" ]
	then
		echo "Error: ntp address mandatory"
		use
	fi

	writeinter $interfile $interfout
	writentp $ntpfile $ntpfout

	# restart network
	# connman automatically detects the changes and apply them when config file is closed
fi
