#!/bin/sh

/etc/init.d/ethernet start
exit $?
