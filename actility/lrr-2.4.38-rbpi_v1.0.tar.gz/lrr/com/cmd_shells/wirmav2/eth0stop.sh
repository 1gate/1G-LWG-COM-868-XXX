#!/bin/sh

/etc/init.d/ethernet stop
exit $?
