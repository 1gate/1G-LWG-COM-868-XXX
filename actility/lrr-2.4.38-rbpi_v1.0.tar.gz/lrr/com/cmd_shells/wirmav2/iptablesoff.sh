#!/bin/sh

/etc/init.d/firewall stop
exit $?
