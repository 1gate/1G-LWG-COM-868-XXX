#!/bin/sh

/etc/init.d/firewall start
exit $?
