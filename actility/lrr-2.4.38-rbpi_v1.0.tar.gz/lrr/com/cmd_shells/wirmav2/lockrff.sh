#!/bin/sh

[ -f "$ROOTACT/lrr/com/_functions.sh" ] && . $ROOTACT/lrr/com/_functions.sh

NFR920=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" "suplog" "nfr920")
[ -z "$NFR920" ] && NFR920=$(getIniConf "$ROOTACT/lrr/config/lrr.ini" "$SYSTEM/suplog" "nfr920")

if	[ "$NFR920" = "1" ]
then
	echo	"lock rff feature disabled, the new backup/restore feature must be used"
	exit 1
fi

touch $ROOTACT/usr/etc/lrr/execrff_locked
exit $?
