#!/bin/sh

ps w
exit $?
