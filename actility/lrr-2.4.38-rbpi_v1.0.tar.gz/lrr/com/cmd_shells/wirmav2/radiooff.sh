#!/bin/sh

/usr/local/bin/modem_off.sh
exit 0
