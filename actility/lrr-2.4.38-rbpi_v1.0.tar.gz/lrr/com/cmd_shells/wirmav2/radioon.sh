#!/bin/sh

/usr/local/bin/modem_on.sh
exit 0
