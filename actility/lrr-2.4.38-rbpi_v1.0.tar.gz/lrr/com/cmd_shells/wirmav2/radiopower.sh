#!/bin/sh

/usr/local/bin/modem_off.sh
sleep 3
/usr/local/bin/modem_on.sh
exit 0
