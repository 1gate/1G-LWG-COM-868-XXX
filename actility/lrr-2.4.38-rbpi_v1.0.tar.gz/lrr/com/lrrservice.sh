#!/bin/sh
#

### BEGIN INIT INFO
# Provides:        lrr
# Required-Start:  $network $remote_fs $syslog
# Required-Stop:   $network $remote_fs $syslog
# Default-Start:   2 3 4 5
# Default-Stop:	   0 6
# Short-Description: Start the lrr
### END INIT INFO

# lrr:       Starts the lrr

exec 2> /dev/null

ROOTACT=_REPLACEWITHROOTACT_
export ROOTACT

CURRENT_DIR=`dirname $0`
. $ROOTACT/lrr/com/functionsservice.sh
. $ROOTACT/lrr/com/_functions.sh

OPTIONS=""
LRR_DATA=$ROOTACT/usr/data/lrr
SERVICE="lrr"
SERVICE_RUNDIR="$ROOTACT/lrr/com"
PIDFILE=$LRR_DATA/lrr.pid
STOPFILE=$LRR_DATA/stop

usage() {
    echo "Usage: lrr [<options>] {start|stop|status|restart}"
    echo "  Where options are:"
    echo "   -h|--help    Print this help message"
}

# Gemtek only
reset_power_rf()
{
        echo	"Reset [GIPO_1Cx] (power_rf_x)..."
        io -w -4 0x2000804c $(( $1&$((0xFFFFF)) ))
        io -w -4 0x2000800c $(( $1&$((0xFFFFF)) ))
        io -w -4 0x2000802c $(( $1&$((0xFFFF0)) ))
        sleep 0.5
        io -w -4 0x2000802c $(( $1&$((0xFFFFF)) ))
}

# Gemtek only
reset_sx1301()	
{
        echo	"Reset [GIPO_1Dx] (sx1301_x)..."
        # EN_GPIO
        io -w -4 0x2000804c $(( $1&$((0xFFFFFFF)) ))
        # DIR_GPIO
        io -w -4 0x2000800c $(( $1&$((0xFFFFFFF)) ))
        # DO_OFF_GW
        io -w -4 0x2000802c $(( $1&$((0xFFFFFFF)) ))
        sleep 0.5
        # DO_ON_GW
        io -w -4 0x2000802c $(( $1&$((0xFFFF0FF)) ))
}

#Raspberry iMST iC880A SPI
WAIT_GPIO() {
    sleep 0.1
}

createVarLogLrr() {

    logdir="$ROOTACT/var/log/lrr"

    ramdir=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" "$SYSTEM" "ramdir")
    if [ -z "$ramdir" ]; then
        ramdir=$(getIniConf "$ROOTACT/lrr/config/lrr.ini" "$SYSTEM" "ramdir")
    fi

    if [ ! -z "$ramdir" ]; then
        # ramdir function enabled

        # create target dir if needed
        mkdir -p $ramdir

        # remove var/log/lrr if it's a standard directory, in order to create a symbolic link
        if [ -d $logdir ]; then
            rm -rf $logdir
        fi

        # remove var/log/lrr if it's a link, to create it correctly, because
        # it's difficult to check if an existing one is the good one
        if [ -L $logdir ]; then
            rm $logdir
        fi

        # create link
        ln -s $ramdir $logdir
    else
        # ramdir function disabled

        # remove link on var/log/lrr if it's a symbolic link
        if [ -L $logdir ]; then
            rm $logdir
        fi
    fi
}

preStart() {
	export PATH=.:$PATH:/usr/local/bin

	mkdir -p $LRR_DATA
	mkdir -p $ROOTACT/usr/etc/lrr > /dev/null 2>&1

	echo "$SYSTEM"

	createVarLogLrr

	## power on radio board on kerlink boxes
	if	[ -f /usr/local/bin/modem_on.sh ]
	then
		echo	"power on radio board with 'modem_on.sh'"
		cd /usr/local/bin
		./modem_on.sh
	else
		echo	"no command to power on radio board"
	fi

	# reset radio boards on Gemtek
	if [ "$SYSTEM" = "gemtek" ]
	then
		# reset board 0 (/dev/spidev0.0)
		reset_power_rf 0x10001
                reset_sx1301 0x1000100
		# reset board 1 (/dev/spidev1.0)
		reset_power_rf 0x20002
		reset_sx1301 0x2000200
	fi

	# usefull on raspberry pi
	if	[ -x /usr/local/bin/gpio ]
	then
		/usr/local/bin/gpio drive 0 0
	fi

	# treat watchdog for kerlink multislots
	if [ "$SYSTEM" = "wirmams" -o "$SYSTEM" = "wirmaar" ]
	then
		echo "start watchdog"
		watchdog /dev/watchdog

		dirbackact="/.update/packages/backupactility"
		dirback="/.update/packages/backup"
		dirbackupsav="/.update/packages/backup.savact"
		# after an execrff, backup directory disappear => restore it
		if [ -d "$dirbackupsav" -a ! -d "$dirback" ]
		then
			echo "restore backup directory after execrff"
			mount /dev/mmcblk3p2 /.update/ -o remount,rw
			mv $dirbackupsav $dirback
			sync
			mount /dev/mmcblk3p2 /.update/ -o remount,ro
		fi

		if [ -d "$dirbackact" ]
		then
			echo "synchronize backup with actility backup"
			mount /dev/mmcblk3p2 /.update/ -o remount,rw
			lst=$(ls $dirbackact/*.ipk)
			for f in $lst
			do
				# rename lrr_1.6.3_cortexa9hf-vfp-neon.ipk to lrr.ipk
				shortname=$(basename $f | awk 'BEGIN { FS="_" } ; { print $1 }')
				rm -f $dirback/${shortname}_*.ipk
				rm -f $dirback/${shortname}.ipk
				cp $f $dirback/$shortname.ipk
			done
			sync
			mount /dev/mmcblk3p2 /.update/ -o remount,ro
		fi

		if [ "$SYSTEM" = "wirmaar" ]
		then
			calibfile="/tmp/calib_loraloc.json"
			calibfilesav="$ROOTACT/usr/etc/lrr/calib_loraloc.json.sav"
			dyninifile="$ROOTACT/usr/etc/lrr/dyncalib.ini"
			if [ -f "$calibfile" ]
			then
				echo "Analyze calibration ..."
				cp $calibfile $calibfilesav
				python $ROOTACT/lrr/com/shells/wirmaar/convjson.py $calibfilesav > $dyninifile
				echo "File $dyninifile created"
			fi
		fi
	fi

	if [ "$SYSTEM" = "tek_micro8" ]
	then
        #hard reset of the sx1301 is needed before lrr.x is started
		fpga-access -w 9,7096
		fpga-access -w 9,3000
	fi
	if [ "$SYSTEM" = "tektelic" -o "$SYSTEM" = "tek_macro16" -o "$SYSTEM" = "tek_micro8" -o "$SYSTEM" = "tek_dish64" ]
	then
		savdir="/home/backupactility"
		execrfffile="$savdir/RESTOREREQUESTED"
		lrrtarfile="$savdir/lrr.tar.gz"
		lrrconftarfile="$savdir/lrrconf.tar.gz"
		lrrdir=$ROOTACT/lrr
		lrrconf=$ROOTACT/usr/etc/lrr
		if [ -f "$execrfffile" -a -f "$lrrtarfile" -a -f "$lrrconftarfile" ]
		then
			echo "execrff has been requested, restoring lrr ..."
			rm -rf $lrrdir
			rm -rf $lrrconf
			cd /
			[ -f "$lrrtarfile" ] && tar xf $lrrtarfile
			[ -f "$lrrconftarfile" ] && tar xf $lrrconftarfile

			# exerff done, remove execrff file
			rm -f $execrfffile
			sync
			# reboot needed because network config files were restored
			echo "rebooting after execrff ..."
			$ROOTACT/lrr/com/cmd_shells/reboot_pending.sh 5
		elif [ -f "$execrfffile" ]
		then
			echo "execrff has been requested but no backup found ! Abort."
			rm -f $execrfffile
		fi
	fi

	if [ "$SYSTEM" = "wirmana" ]
	then
		savdir="/.update/backupactility"
		execrfffile="$savdir/RESTOREREQUESTED"
		lrrtarfile="$savdir/lrr.tar.gz"
		lrrconftarfile="$savdir/lrrconf.tar.gz"
		lrrdir=$ROOTACT/lrr
		lrrconf=$ROOTACT/usr/etc/lrr
		# disable ipv6 to avoid slow DNS resolution, leading to failure of reverse ssh (PT-789)
		sysctl -w net.ipv6.conf.all.disable_ipv6=1
		if [ -f "$execrfffile" ]
		then
			echo "execrff has been requested, restoring lrr ..."
			rm -rf $lrrdir
			rm -rf $lrrconf
			cd /
			[ -f "$lrrtarfile" ] && tar xf $lrrtarfile
			[ -f "$lrrconftarfile" ] && tar xf $lrrconftarfile

			# exerff done, remove execrff file
			mount /dev/mmcblk3p2 /.update/ -o remount,rw
			rm -f $execrfffile
			sync
			mount /dev/mmcblk3p2 /.update/ -o remount,ro
			# reboot needed because network config files were restored
			echo "rebooting after execrff ..."
			$ROOTACT/lrr/com/cmd_shells/reboot_pending.sh 5
		fi
	fi

	if [ "$SYSTEM" = "ciscoms" ]; then
		shcalib="$ROOTACT/lrr/com/shells/ciscoms/set_lut_calib.sh"
		if [ ! -f $shcalib ]; then
			echo "Warning: $shcalib tool not found !"
		else
			echo "Analyse calibration ..."
			$shcalib
			ret=$?
			if [ $ret -ne 0 ]; then
				echo "Error during LUT calibration process (err $ret)"
			fi
		fi
	fi

	if [ "$SYSTEM" = "fcloc" -o "$SYSTEM" = "fcmlb" ]; then
		echo "Configuring GPS stty driver"
		stty -F /dev/ttyS5 -echo igncr
	fi

	if [ "$SYSTEM" = "mtac_v1.0" -o "$SYSTEM" = "mtac_v1.5" -o "$SYSTEM" = "mtac_refresh_v1.5" -o "$SYSTEM" = "mtcdt_ip67" ]; then
		echo "Use /dev/spidev0.0 regardless of the used MTAC / MTCDT_IP67 AP1 or AP2 slot, usage of SLOT AP2 is preferred"
		port1=/sys/devices/platform/mts-io/ap1
		port2=/sys/devices/platform/mts-io/ap2
		lora_hw=$(mts-io-sysfs show lora/hw-version 2> /dev/null)
		if [ -d $port2 ] && [[ $(cat $port2/hw-version) = $lora_hw ]]; then
			ln -sf /dev/spidev32765.2 /dev/spidev0.0
			echo "SLOT AP2 is now being used"
		elif [ -d $port1 ] && [[ $(cat $port1/hw-version) = $lora_hw ]]; then
			ln -sf /dev/spidev32766.2 /dev/spidev0.0
			echo "SLOT AP1 is now being used"
		fi
	fi

	if [ "$SYSTEM" = "rbpi_v1.0" ]; then
		IOT_SK_SX1301_RESET_PIN=5
		echo "17" > /sys/class/gpio/export
		echo "out" > /sys/class/gpio/gpio17/direction
		echo "1" > /sys/class/gpio/gpio17/value
		sleep 5
		echo "0" > /sys/class/gpio/gpio17/value
		sleep 1
		echo "0" > /sys/class/gpio/gpio17/value
		if [ -d /sys/class/gpio/gpio$IOT_SK_SX1301_RESET_PIN ]
		then
			echo "$IOT_SK_SX1301_RESET_PIN" > /sys/class/gpio/unexport; WAIT_GPIO
		fi
		# setup GPIO 7
		echo "$IOT_SK_SX1301_RESET_PIN" > /sys/class/gpio/export; WAIT_GPIO
		# set GPIO 7 as output
		echo "out" > /sys/class/gpio/gpio$IOT_SK_SX1301_RESET_PIN/direction; WAIT_GPIO
		# write output for SX1301 reset
		echo "1" > /sys/class/gpio/gpio$IOT_SK_SX1301_RESET_PIN/value; WAIT_GPIO
		echo "0" > /sys/class/gpio/gpio$IOT_SK_SX1301_RESET_PIN/value; WAIT_GPIO
	fi


    #start get_gateway_info.sh script to get various information in the GW
    $ROOTACT/lrr/com/cmd_shells/get_gateway_info.sh

}

serviceCommand() {
	echo "lrr.x "$OPTIONS
	if [ "$SYSTEM" == "fcpico"  ]; then
		echo "1" > /sys/class/gpio/gpio67/value
	fi
    if [ "$SYSTEM" = "tracknet" ]; then
        /usr/share/tracknet/reset_gw_tn.sh 0
    fi
}

stopService() {
	LRR_PIDS=$(pidof lrr.x)
	[ -n "$LRR_PIDS" ] && kill -TERM $LRR_PIDS
	if [ "$SYSTEM" == "fcpico" ]; then
		echo "0" > /sys/class/gpio/gpio67/value
	fi
}

abortService() {
	LRR_PIDS=$(pidof lrr.x)
	[ -n "$LRR_PIDS" ] && kill -KILL $LRR_PIDS
	if [ "$SYSTEM" == "fcpico" ]; then
		echo "0" > /sys/class/gpio/gpio67/value
	fi
}

[ -f "$ROOTACT/usr/etc/lrr/_parameters.sh" ] && . $ROOTACT/usr/etc/lrr/_parameters.sh
export SYSTEM

# getopt is not present on major gw
if [ "$SYSTEM" != "ir910" -a "$SYSTEM" != "fcmlb" -a "$SYSTEM" != "fcpico" -a "$SYSTEM" != "fclamp" -a "$SYSTEM" != "wirmams" -a "$SYSTEM" != "wirmaar" -a "$SYSTEM" != "fcloc" -a "$SYSTEM" != "wirmana" -a "$SYSTEM" != "tektelic" -a "$SYSTEM" != "tek_macro16" -a "$SYSTEM" != "tek_micro8" -a "$SYSTEM" != "flexpico" -a "$SYSTEM" != "tek_dish64" -a "$SYSTEM" != "tracknet" ]
then
	GETOPTTEMP=`getopt -o a:hi --long help,init -- $@`
	if [ $? != 0 ] ; then usage >&2 ; exit 1 ; fi
	eval set -- "$GETOPTTEMP"

	# Read the arguments
	while [ -n "$1" ]
	do
	    case "$1" in
		"-a") shift; OPTIONS=$OPTIONS" -a "$1;;
		"-h"|"--help") usage; exit;;
		"-i"|"--init") OPTIONS=$OPTIONS" -i";;
		"--") shift; break ;;
		* ) echo "Internal error ($*)!"; exit 1;;
	    esac
	    shift
	done
fi

handleParams $*

exit $?

