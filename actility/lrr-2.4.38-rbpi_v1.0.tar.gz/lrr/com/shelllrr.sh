#!/bin/sh

#PATH=${PATH//".:"/}
#PATH=${PATH//":.:"/}
export PATH=.:$PATH

LRRCMDSERIAL="0"
export LRRCMDSERIAL

COMMAND="${1}"
shift

DATE=$(date +%FT%T%z)

if	[ -z "$COMMAND" ]
then
	echo	"#no command"
	exit	1
fi

if	[ "${1}" = "-Z" ]
then
	shift
	LRRCMDSERIAL="${1}"
	export LRRCMDSERIAL
	shift
fi

if	[ "$COMMAND" = "stoplrr" -o "$COMMAND" = "stoplrr.sh" ]
then
	echo	"#lrr can not stop itself"
	exit	1
fi

if	[ "$COMMAND" = "startlrr" -o "$COMMAND" = "startlrr.sh" ]
then
	echo	"#lrr can not start itself"
	exit	1
fi

if	[ -z "$ROOTACT" ]
then
	export ROOTACT=/mnt/fsuser-1/actility
fi

if	[ ! -d "$ROOTACT" ]
then
	echo	"#ROOTACT does not exist"
	exit	1
fi

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

lrr_CloseFiles

# old installs do not have SYSTEM in _parameters.sh
if	[ -z "$SYSTEM" ]
then
	SYSTEM=$LRRSYSTEM
fi
export SYSTEM

echo	"#"
echo	"#DATE=$DATE"
#echo	"#SYSTEM=$SYSTEM"
echo	"#LRRSYSTEM=$LRRSYSTEM"
echo	"#ROOTACT=$ROOTACT"
echo	"#LRRCMDSERIAL=$LRRCMDSERIAL"

cd $ROOTACT
DIRCUSTOM=$ROOTACT/usr/etc/lrr/cmd_shells
DIRCOMMAND=$ROOTACT/lrr/com/cmd_shells

PENDINGFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}_pending
TERMFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}_terminated
PPIDFILE=${ROOTACT}/usr/data/lrr/cmd_shells/${LRRCMDSERIAL}.pid
# command specific to the customer
if	[ -x ${DIRCUSTOM}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCUSTOM}/${COMMAND}.sh $*"
	echo "#"
	${DIRCUSTOM}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
fi

# command specific to the system but in the package
if	[ -x ${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh $*"
	echo "#"
	${DIRCOMMAND}/${LRRSYSTEM}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
fi

# generic command
if	[ -x ${DIRCOMMAND}/${COMMAND}.sh ]
then
	echo $$ > $PPIDFILE
	echo "#${DIRCOMMAND}/${COMMAND}.sh $*"
	echo "#"
	${DIRCOMMAND}/${COMMAND}.sh $*
	ret=$?
	pid=$!
	echo $ret > $TERMFILE
	[ -f $PPIDFILE ] && rm $PPIDFILE 2> /dev/null 2>&1
	[ -f $PENDINGFILE ] && rm $PENDINGFILE 2> /dev/null 2>&1
	exit $ret
fi

echo	"#command ${COMMAND}.sh not found"

exit 1
