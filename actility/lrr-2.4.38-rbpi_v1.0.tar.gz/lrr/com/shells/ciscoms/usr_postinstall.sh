#!/bin/sh
ROOTACT=/tmp/mdm/pktfwd/firmware

cat $ROOTACT/usr/etc/lrr/customer_hosts > /etc/hosts
cat $ROOTACT/usr/etc/lrr/customer_nsswitch > /etc/nsswitch.conf

touch /var/log/btmp
chmod 600 /var/log/btmp

if [[ -f $ROOTACT/usr/etc/lrr/seed && -f $ROOTACT/usr/etc/lrr/keygen && -f $ROOTACT/usr/etc/lrr/keygen.sh ]]
then
	$ROOTACT/usr/etc/lrr/keygen.sh update_pwd
	rm $ROOTACT/usr/etc/lrr/keygen.sh
fi

#Get the model name and HAL version from lrr.x output
HAL=$($ROOTACT/lrr/com/lrr.x --version | grep -i hal | sed -r 's/.*HAL ([^ ]+).*/\1/' | sed 's/;//')

CUSTOM_BUILD_VERSION=orange
CONFIGURATION_VERSION=1.05

HARDWARE_VERSION=
OS_VERSION=
DATE=`date "+%Y-%m-%d_%H%M%S"`


if grep -Fxq "[versions]" $ROOTACT/usr/etc/lrr/lrr.ini
then
    sed -i "/hardware_version*./c\    hardware_version=" $ROOTACT/usr/etc/lrr/lrr.ini
	sed -i "/os_version*./c\    os_version=" $ROOTACT/usr/etc/lrr/lrr.ini
	sed -i "/hal_version*./c\    hal_version=$HAL" $ROOTACT/usr/etc/lrr/lrr.ini
	sed -i "/custom_build_version*./c\    custom_build_version=$CUSTOM_BUILD_VERSION" $ROOTACT/usr/etc/lrr/lrr.ini
	sed -i "/configuration_version*./c\    configuration_version=$CONFIGURATION_VERSION" $ROOTACT/usr/etc/lrr/lrr.ini
	sed -i "/custom1_version=*./c\    custom1_version=install-date-$DATE" $ROOTACT/usr/etc/lrr/lrr.ini
else
    echo >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "[versions]" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    hardware_version=$HARDWARE_VERSION" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    os_version=$OS_VERSION" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    hal_version=$HAL" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    custom_build_version=$CUSTOM_BUILD_VERSION" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    configuration_version=$CONFIGURATION_VERSION" >> $ROOTACT/usr/etc/lrr/lrr.ini
	echo "    custom1_version=install-date-$DATE" >> $ROOTACT/usr/etc/lrr/lrr.ini
fi
