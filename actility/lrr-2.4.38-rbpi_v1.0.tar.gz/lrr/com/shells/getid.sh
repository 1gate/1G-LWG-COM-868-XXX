#!/bin/sh
#
#	get gateway uid
#	This shell must return the gateway uniq identifier
#	The string return must be alphanum only
#
#Get Cisco lrrID functions
get_sn() {

    CISCOSN=$(getsn)
    return
}

check_format() {
    # must be LLLDDDDAAAA
    check=$(echo $CISCOSN | grep -E '^[A-Z]{3}[0-9]{4}[A-Z0-9]{4}$')
    if [ "${check}" = "" ]; then
        echo "$CISCOSN is not a valid CISCOSN"
        exit 1
    fi
}

ord() {
  printf '%d' "'$1"
}

get_c() {
    # extract from $1, length $2
    C=${CISCOSN:${1}:${2}}
}

get_ord() {
    get_c $1 1
    C=$(ord $C)
}

get_alnum() {
    get_c $1 1
    if [ "$C" -eq "$C" ] 2>/dev/null
    then
        val=$C
    else
        val=$(ord $C)
        val=$(( $val - $A + 10 ))
    fi
    C=$val
}

csn_code() {
    # keep L % 4
    A=$(ord 'A')
    zero=$(ord '0')

    get_ord 0
    c0=$(( ($C - $A) % 4))
    get_ord 1
    c1=$(( ($C - $A) % 4))
    get_ord 2
    c2=$(( ($C - $A) % 4))
    lll=$(( ($c0 * 16) + ($c1 * 4) + $c2))
    lll=$(( $lll *3 * 26 * 18 * 36 * 36 * 36 ))

    # keep YY %3
    get_c 3 2
    yy=$(( $C % 3 ))
    yy=$(( $yy * 26 * 18 * 36 * 36 * 36 ))

    # keep WW % 26
    get_c 5 2
    ww=$(( ($C - 1) % 26 ))
    ww=$(( $ww * 18 * 36 * 36 * 36 ))


    get_alnum 7
    c7=$C
    v7=$(( ($c7 % 18) * 36 * 36 * 36 ))
    get_alnum 8
    c8=$C
    v8=$(( $c8 * 36 * 36 ))
    get_alnum 9
    c9=$C
    v9=$(( $c9 * 36 ))
    get_alnum 10
    c10=$C
    v10=$c10
    ssss=$(( $v7 + $v8 + $v9 + $v10 ))

    res=$(( $lll + $yy + $ww + $ssss ))
    if [ $LOWER -eq 1 ]; then
        RES=$(printf "%08x\n" "$res")
    else
        RES=$(printf "%08X\n" "$res")
    fi

}







while	[ $# -gt 0 ]
do
	case	$1 in 
		-o)
			shift
			MODE="oui"
		;;
		-u)
			shift
			MODE="uid"
		;;
		*)
			shift
		;;
	esac
done

oui='uniden'
uid='unidentified'
case	$SYSTEM in
	natrbpi)
	;;
	fcmlb|fcloc|fcpico)
		oui='001558'
		uid=$(nvram get bs_id)
	;;
	ciscoms)
		LOWER=1
		oui='005f86'
		get_sn
		check_format
		csn_code
                lrrid=$RES
                uid=024b0$lrrid
	;;
	wirma*)
		oui='7076ff'
		uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
	;;
	mtac*|mtcap|mtcdt*)
		oui='000800'
		uid=$(mts-io-sysfs show device-id)
	;;
	flexpico)
		oui='000900'
		uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
        ;;
	oielec)
		oui='d84a87' #waiting for oielec confirmation
		uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
	;;
	linux*)
		oui='0016C0'
		uid=$($ROOTACT/lrr/com/lrr.x --stpicoid)
        ;;
        gemtek)
                oui='1c497b'
                uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
        ;;
	tek*)
		oui='647FDA'
		uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
        ;;
    tracknet*)
        if [ ! -z "$(uname -a | grep -i TabsHub)" ]; then
            oui='58a0cb'
        else
            oui='1c497b'
        fi
        uid=$(ifconfig eth0 | grep HWaddr | awk '{ print $5 }' | sed 's/://g' | tr '[:upper:]' '[:lower:]')
        ;;

esac

# New requirement: results must now be in uppercase
oui=$(echo $oui | tr '[:lower:]' '[:upper:]')
uid=$(echo $uid | tr '[:lower:]' '[:upper:]')

# Verbose off when used from sysconfiglrr.sh to set LRRUID in _parameters.sh
if [ "$MODE" = "oui" ]
then
	echo "$oui"
elif [ "$MODE" = "uid" ]
then
	echo "$uid"
else
	echo "Vendor oui:'$oui' Gateway uid:'$uid'"
fi
