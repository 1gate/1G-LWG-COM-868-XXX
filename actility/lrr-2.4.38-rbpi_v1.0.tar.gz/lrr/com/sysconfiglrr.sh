#!/bin/sh

# ask a question
# $1: variable name for the result
# $2: question to ask
# $3 $4 ...: choices
ask()
{
	resvarname="$1"
	question="$2"
	shift 2
	choice="$*"

	resp=0
	while [ $resp = 0 ]
	do
		# ask question
		echo "$question"

		# display choices
		count=1
		set $choice
		tot=$#
		while [ $count -le $tot ]
		do
			echo "$count	$1"

			shift
			count=$(($count + 1))
		done

		# get response
		echo -n "> "
		read resp

		# check response
		[ $resp -gt 0 -a $resp -lt $count ] && break
		resp=0
	done

	# set resulting variable with the choice made
	set $choice
	eval "$resvarname=\$$resp"
}

checkSupportUser()
{
	if [ "$SYSTEM" = "linux-x86" ]; then
		return
	fi
	if [ "$SYSTEM" = "linux-x86_64" ]; then
		return
	fi

	DEFAULT_SHELL=/bin/sh
	if [ "$SYSTEM" = "flexpico" ]; then
		DEFAULT_SHELL=/bin/ash
	fi

	# create /etc/shells if required
	if [ ! -f "/etc/shells" ]
	then
		echo "$DEFAULT_SHELL" >>/etc/shells
		echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
	else
		# if /etc/shells exists, check if suplog.x is present
		check="$(grep "suplog.x" /etc/shells)"
		[ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
	fi

	STDOPT="-s"
	if [ "$SYSTEM" = "oielec" ]; then
		STDOPT="--shell"
	fi
	PWD_FILE=/etc/passwd
	# create user support if required
	check="$(grep "^support:" $PWD_FILE)"
	if [ -z "$check" ]
	then
		if [ "$SYSTEM" = "flexpico" ]; then
			# no adduser command on flexpico. Add support user manually
			echo "support:*:1000:1000:Support User:$ROOTACT:$ROOTACT/lrr/suplog/suplog.x" >> /etc/passwd
			passwd support <<END_ADD
support
support
END_ADD
		else
		adduser $STDOPT $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
support
support
END_ADD
		fi
	else
		#check that the user support has a different ID from root
		check="$(grep "^support:x:0" $PWD_FILE)"
		if [ ! -z "$check" ]
		then
			SUPPORTID=1000
			check="$(grep $SUPPORTID $PWD_FILE)"
			while [ ! -z "$check" ]
			do
				let SUPPORTID=SUPPORTID+1
				check="$(grep $SUPPORTID $PWD_FILE)"
			done
			SUPPORTGROUP="$(id -g support)"
			sed -i "s/support:x:0:${SUPPORTGROUP}/support:x:${SUPPORTID}:${SUPPORTID}/g" $PWD_FILE
		fi

		# check the existing user support has suplog.x as shell
		check=$(grep "^support:" $PWD_FILE | grep suplog.x)
		if [ -z "$check" ]
		then
			sed -i "/^support/s#/${DEFAULT_SHELL}#${ROOTACT}/lrr/suplog/suplog.x#g" $PWD_FILE
		fi
	fi

	# check setuid bit on /bin/su
}

checkSupportUserWirmaMS()
{
	[ -f "/user/login" ] && rm -f /user/login

	[ -f "$ROOTACT/lrr/suplog/suplog.x" ] && ln -s $ROOTACT/lrr/suplog/suplog.x /user/login
}

checkSupportUserWirmaAR()
{
	# command klk_set_passwd not available at 'postinst' time
	# change password by modifying /etc/shadow (kerlink recommendation !)
	# check if /user/login is linked to suplog (upgrade) or not (initial install)
	LINK=`ls -l /user/login | grep suplog`
	if [ -z "$LINK" ]; then
		# initial installation
		sed -i -e '/support/ s/support:.*/support:$1$T.thdwGL$TiEFih3F0zxhVF12mWVrN\/:16896:0:99999:7:::/' /user/rootfs_rw/etc/shadow
	fi

	rm -f /user/login
	[ -f "$ROOTACT/lrr/suplog/suplog.x" ] && ln -s $ROOTACT/lrr/suplog/suplog.x /user/login

	cfgssh="/user/rootfs_rw/etc/ssh/sshd_config"
	res=$(grep "AllowUsers.*support" $cfgssh)
	[ -z "$res" ] && echo "AllowUsers support" >> $cfgssh
}

checkSupportUserWirmaNA()
{
	checkSupportUserWirmaAR
}

checkSupportUserCiscoms()
{
	# As permissions are more restrictive by default than others gateways,
	chmod -R g=rwX,o=rX $ROOTACT
	chmod 777 /tmp
	# Create group users GID 100 if needed
	check="$(grep "^users:" /etc/group)"
	if [ -z "$check" ];  then
		addgroup users -g 100
	else
		echo "group users already exists"
	fi
	# Create user support UID 1001 if needed
	check="$(grep "^support:" /etc/passwd)"
	if [ -z "$check" ];  then
		adduser support -u 1001 -G users -g "Support LRR" -s $ROOTACT/lrr/suplog/suplog.x << END_ADD
support
support
END_ADD
	else
		echo "user support already exists"
	fi
	# Add umask in profile if needed
	line=$(grep "umask 002" $INIT_PROF)
	if [ -z "$line" ]; then
		echo "umask 002" >> $INIT_PROF
	else
		echo "umask already present in $INIT_PROF"
	fi

	# Because permissions where not already available
	chown root:root $ROOTACT/lrr/suplog/suplog.x
	chmod u+s $ROOTACT/lrr/suplog/suplog.x
}

checkSupportUserGemtek()
{
        # create /etc/shells if required
        if [ ! -f "/etc/shells" ]
        then
                echo "/bin/sh" >>/etc/shells
                echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        else
                # if /etc/shells exists, check if suplog.x is present
                check="$(grep "suplog.x" /etc/shells)"
                [ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
        fi

        STDOPT="-shell"
        PWD_FILE=/etc/passwd
        # create user support if required
        check="$(grep "^support:" $PWD_FILE)"
        if [ -z "$check" ]
        then
                adduser $STDOPT $ROOTACT/lrr/suplog/suplog.x support <<END_ADD
support
support




y
END_ADD
        else
                #check that the user support has a different ID from root
                check="$(grep "^support:x:0" $PWD_FILE)"
                if [ ! -z "$check" ]
                then
                        SUPPORTID=1000
                        check="$(grep $SUPPORTID $PWD_FILE)"
                        while [ ! -z "$check" ]
                        do
                                let SUPPORTID=SUPPORTID+1
                                check="$(grep $SUPPORTID $PWD_FILE)"
                        done
                        SUPPORTGROUP="$(id -g support)"
                        sed -i "s/support:x:0:${SUPPORTGROUP}/support:x:${SUPPORTID}:${SUPPORTID}/g" $PWD_FILE
                fi

                # check the existing user support has suplog.x as shell
                check=$(grep "^support:" $PWD_FILE | grep suplog.x)
                if [ -z "$check" ]
                then
                        sed -i "/^support/s#/bin/sh#${ROOTACT}/lrr/suplog/suplog.x#g" $PWD_FILE
                fi
        fi

        # check setuid bit on /bin/su
}

checkSupportUserTracknet()
{
   # create /etc/shells if required
   if [ ! -f "/etc/shells" ]
   then
       echo "/bin/sh" >>/etc/shells
       echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
   else
       # if /etc/shells exists, check if suplog.x is present
       check="$(grep "suplog.x" /etc/shells)"
       [ -z "$check" ] && echo "$ROOTACT/lrr/suplog/suplog.x" >>/etc/shells
   fi
   
   # Create group users GID 100 if needed
   check="$(grep "^users:" /etc/group)"
   if [ -z "$check" ];  then
       addgroup users -g 100
   else
       echo "group users already exists"
   fi
   # Create user support UID 1001 if needed
   check="$(grep "^support:" /etc/passwd)"
   if [ -z "$check" ];  then
       mkdir -p /home/support
       adduser support -u 1001 -G users -g "Support LRR" -s $ROOTACT/lrr/suplog/suplog.x << END_ADD
support
support
END_ADD
   else
       echo "user support already exists"
   fi
   
   # Allow support user to be super user
   chown root:root $ROOTACT/lrr/suplog/suplog.x
   chmod u+s $ROOTACT/lrr/suplog/suplog.x
}

disableCfgmgr()
{
	echo "Disable cfgmgr Ethernet link checking"
	# on ufiSpace, cfgmgr performs an Ethernet link control detecting
	# connection loss. Unfortunately, it causes unstability as it 
	# "pings" server other than LRC so detects link loss inappropriately
	# check conf file presence (depends on the firmware and the gateway model)
	cfgmgr=/etc/cfgmgr.conf
	savcfg=/etc/cfgmgr.orig
	if [ -f $cfgmgr ]; then
		# already saved ? Do not supersede the original one from manufacturer
		if [ ! -f $savcfg ]; then
			cp $cfgmgr $savcfg
		fi
		echo "enable=0" > $cfgmgr
		echo "checkwanfreq=0" >> $cfgmgr
	fi
}

addIptables_wirmav2()
{
	type iptables > /dev/null 2>&1
	if [ $? != "0" ]
	then
		echo	"iptables are not available"
		return 1
	fi
	if [ ! -f /etc/init.d/firewall.kerlink -a -f /etc/init.d/firewall ]
	then
		cp /etc/init.d/firewall /etc/init.d/firewall.kerlink
	fi

	cp $ROOTACT/lrr/com/shells/wirmav2/firewall /etc/init.d/firewall
	chmod +x /etc/init.d/firewall
	rm -f /etc/rc.d/rc3.d/S80firewall
	ln -s /etc/init.d/firewall /etc/rc.d/rc3.d/S80firewall

	echo "SERVICEFIREWALL=/etc/init.d/firewall" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	echo	"iptables are installed"
	return 0
}

addIptables_wirmams()
{
	cat $ROOTACT/lrr/com/shells/wirmams/firewall | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /user/rootfs_rw/etc/rcU.d/S89lrrfirewall
	chmod +x /user/rootfs_rw/etc/rcU.d/S89lrrfirewall

	echo "SERVICEFIREWALL=/etc/rcU.d/S89lrrfirewall" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	echo	"iptables are installed"
	return 0
}

addIptables_wirmaar()
{
	addIptables_wirmams
}

addIptables()
{
	if [ ! -f /etc/init.d/firewall.original -a -f /etc/init.d/firewall ]
	then
		cp /etc/init.d/firewall /etc/init.d/firewall.original
	fi
	cp $ROOTACT/lrr/com/shells/$SYSTEM/firewall /etc/init.d/firewall
	chmod +x /etc/init.d/firewall

	echo "SERVICEFIREWALL=/etc/init.d/firewall" >> $ROOTACT/usr/etc/lrr/_parameters.sh

	echo	"iptables are installed"
	return 0
}

addHwDetection_wirmaar()
{
	cat $ROOTACT/lrr/com/cmd_shells/wirmaar/checkhw.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /user/rootfs_rw/etc/rcU.d/S87checkhw
	chmod +x /user/rootfs_rw/etc/rcU.d/S87checkhw
    # execute it once
    /user/rootfs_rw/etc/rcU.d/S86checkhw
    echo "Script for Hardware detection installed and executed"
}

addIptables_wirmana()
{
	addIptables_wirmams
}

useBashInteadOfDash(){
	echo "dash dash/sh boolean false" | debconf-set-selections
	dpkg-reconfigure -f noninteractive dash
}

get_multitech_conduit_hw_mcard_version(){
	#Conduit
	# 1 - check for V1.5 SPI Refresh version : it has GPS capabilities and GW HW version >= 0.1
	#     let's ignore people who use a Refresh HW and plug an older mcard
	#get Conduit HW version : 0.0 HW version is a Conduit, O.1 or higher is a Conduit Refresh (GPS)
	hw_ver=$(mts-io-sysfs show hw-version)
	#format the hw_version : MTCDT-0.1 will become 0.1
	hw_ver=${hw_ver#*-}
	declare $(awk 'BEGIN { print ('"$hw_ver"' >= 0.1) ? "hw_refresh=yes" : "hw_refresh=no" }')
	gps_cap=$(mts-io-sysfs show capability/gps)
	if [ "$gps_cap" == "1" ] && [ "$hw_refresh" == "yes" ]; then
	    if [ ! -z "$(mts-io-sysfs show lora/hw-version | grep -i MTAC-LORA-1.5)" ];
	    then
		    echo "Conduit Refresh V1.5 detected (GPS)"
		    SYSTEM=mtac_refresh_v1.5
		    return 1
	    fi
	    lsusb_output=$(lsusb)
	    if [[ $lsusb_output =~ .*Future.* ]];
	    then
		    echo "Conduit Refresh USB V1.0 detected"
		    SYSTEM=mtac_refresh_usb_v1.0
		    return 1
	    fi
        echo "Could not detect Mcard version, will use SPI v1.5 (mtac_refresh_v1.5)"
        SYSTEM=mtac_refresh_v1.5
		return 1
	fi
	# 2 - check for 1.5 SPI
	# if lora hw-version is 1.5 but no gps is detected, it's not a Refresh
	if [ ! -z "$(mts-io-sysfs show lora/hw-version | grep -i MTAC-LORA-1.5)" ];
	then
		echo "Conduit V1.5 detected (no GPS)"
		SYSTEM=mtac_v1.5
		return 1
	fi
	# 3 - it's SPI 1.0 if not V1.5, check if SPI or USB
	# If we can detect the USB FTDI on the USB bus using the lsusb command
	# eg: Bus 001 Device 005: ID 0403:6014 Future Technology Devices International, Ltd FT232H Single HS USB-UART/FIFO IC
	# we can safely assume that the device is USB
	lsusb_output=$(lsusb)
	if [[ $lsusb_output =~ .*Future.* ]];
	then
		echo "Conduit USB V1.0 detected"
		SYSTEM=mtac_usb_v1.0
		return 1
	fi
	#if not then at least check that it's MTAC-LORA-1.0 because some SPI 1.0 device don't include the H or SPI in the product-id....
	if [ ! -z "$(mts-io-sysfs show lora/hw-version | grep -i MTAC-LORA-1.0)" ];
	then
		echo "Conduit V1.0 detected (NO GPS)"
		SYSTEM=mtac_v1.0
		return 1
	fi
	#Fallback mode: the card couldn't be detected so let's assume it's a V1.5 SPI without GPS
	echo "No Conduit version detected, mtac_v1.5 will be used unless the HW is Conduit IP67 and detecter later on"
	SYSTEM=mtac_v1.5
	return 1
}


# -o "$product_id" = "T000"


get_tektelic_hw_version() {
	if [ ! -f ${ROOTACT}/lrr/com/get_tektelic_version.x ]
	then
		echo "System : tektelic - Cannot detect Tektelic HW version, defaulting to tektelic"
		SYSTEM=tektelic
        return 1
	fi
	product_id=$(${ROOTACT}/lrr/com/get_tektelic_version.x | grep "Product" | awk '{print $3}')
	if [ "$product_id" = "T0005527" -o "$product_id" = "T0004565" -o "$product_id" = "T0004978" -o "$product_id" = "T0004980" -o "$product_id" = "T0004982" -o "$product_id" = "T0004984" -o "$product_id" = "T0005134" -o "$product_id" = "T0005136" -o "$product_id" = "T0005138" -o "$product_id" = "T0005140" -o "$product_id" = "T0005004" -o "$product_id" = "T0005006" -o "$product_id" = "T0005008" -o "$product_id" = "T0005010" -o "$product_id" = "T0004974" -o "$product_id" = "T0004719" -o "$product_id" = "T0004946" -o "$product_id" = "T0004976" -o "$product_id" = "T0004996" -o "$product_id" = "T0004998" -o "$product_id" = "T0005000" -o "$product_id" = "T0005002" -o "$product_id" = "T0004142" -o "$product_id" = "T0004470" -o "$product_id" = "T0004537" -o "$product_id" = "T0004250" -o "$product_id" = "T0004251" -o "$product_id" = "T0004252" -o "$product_id" = "T0004988" -o "$product_id" = "T0004990" -o "$product_id" = "T0004992" -o "$product_id" = "T0004994" ]
	then
        SYSTEM=tektelic
        echo "System : tektlic - Tektelic North America Kona64 Mega detected"
        return 1
	fi
	if [ "$product_id" = "T0005259" -o "$product_id" = "T000526" -o "$product_id" = "T0005186" -o "$product_id" = "T0005187" -o "$product_id" = "T0005265" -o "$product_id" = "T0005266" -o "$product_id" = "T0005267" -o "$product_id" = "T0005268" -o "$product_id" = "T0005251" -o "$product_id" = "T0005252" -o "$product_id" = "T0005169" -o "$product_id" = "T0005179" -o "$product_id" = "T0005253" -o "$product_id" = "T0005254" -o "$product_id" = "T0005180" -o "$product_id" = "T0005181" -o "$product_id" = "T0005249" -o "$product_id" = "T0005250" -o "$product_id" = "T0005130" -o "$product_id" = "T0005131" -o "$product_id" = "T0005255" -o "$product_id" = "T0005256" -o "$product_id" = "T0005182" -o "$product_id" = "T0005183" -o "$product_id" = "T0005247" -o "$product_id" = "T0005248" -o "$product_id" = "T0004937" -o "$product_id" = "T0005129" -o "$product_id" = "T0005261" -o "$product_id" = "T0005262" -o "$product_id" = "T0005263" -o "$product_id" = "T0005264" -o "$product_id" = "T0005257" -o "$product_id" = "T0005258" -o "$product_id" = "T0005184" -o "$product_id" = "T0005185" -o "$product_id" = "T0005269" -o "$product_id" = "T0005270" -o "$product_id" = "T0005271" -o "$product_id" = "T0005272" ]
	then
        SYSTEM=tek_macro16
        echo "System : tek_macro16 - Tektelic North America or European Kona16 Macro detected"
        return 1
	fi
    #T0000000 Procuct Code is used for PoC
	if [ "$product_id" = "T0000000" -o "$product_id" = "T0005519" ]
	then
        SYSTEM=tek_dish64
        echo "System : tek_dish64 - Tektelic North America Kona64 Mega DISH detected"
        return 1
	fi
	if [ "$product_id" = "" ]
	then
        SYSTEM=tektelic
        echo "No TCODE detected, will default to Mega64 : tektelic system"
        return 1
	fi
    
}

installService()
{
	shname="$1"
	srvname="$2"

	case $SYSTEM in
		wirmav2)	#Kerlink
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc.d/rc3.d/S90$srvname" ]
			then
				# default runlevel is 3
				# according to kerlink wiki, lvl 2 and 4 are reserved for kerlink stuff
				ln -s /etc/init.d/$srvname /etc/rc.d/rc3.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc.d/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc.d/rc6.d/K01$srvname
			fi
		;;
		wirmams)	#Kerlink
			# need to use /user/rootfs_rw/etc/rcU.d/S90lrr instead of /etc/rcU.d/S90lrr
			# because at ipk installation time /etc/rcU.d does not exist yet
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /user/rootfs_rw/etc/rcU.d/S90$srvname
			chmod +x /user/rootfs_rw/etc/rcU.d/S90$srvname
		;;
		wirmaar)	#Kerlink
			# need to use /user/rootfs_rw/etc/rcU.d/S90lrr instead of /etc/rcU.d/S90lrr
			# because at ipk installation time /etc/rcU.d does not exist yet
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /user/rootfs_rw/etc/rcU.d/S90$srvname
			chmod +x /user/rootfs_rw/etc/rcU.d/S90$srvname
		;;
		wirmana)	#Kerlink
			# need to use /user/rootfs_rw/etc/rcU.d/S90lrr instead of /etc/rcU.d/S90lrr
			# because at ipk installation time /etc/rcU.d does not exist yet
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /user/rootfs_rw/etc/rcU.d/S90$srvname
			chmod +x /user/rootfs_rw/etc/rcU.d/S90$srvname
		;;
		rbpi_v1.0)	#RaspBerry SPI V1.0
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S90$srvname" ]
			then
				ln -s /etc/init.d/$srvname /etc/rc2.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc3.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc4.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc5.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		natrbpi_usb_v1.0)	#RaspBerry USB V1.0
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S90$srvname" ]
			then
				ln -s /etc/init.d/$srvname /etc/rc2.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc3.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc4.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc5.d/S90$srvname
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		ir910)		#Cisco
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /mnt/apps/etc/init.d/S06init$srvname
			chmod +x /mnt/apps/etc/init.d/S06init$srvname
		;;

		ciscoms)	#Cisco lora-modem multislots
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/S90init$srvname
			chmod +x /etc/init.d/S90init$srvname
		;;

		tektelic|tek_macro16|tek_micro8|tek_dish64)	#Tektelic
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S99$srvname" ]
			then
				# remove '2&>1', the command do nothing with that !
				# ln -s /etc/init.d/$srvname /etc/rc2.d/S99$srvname > /dev/null 2&>1
				ln -s /etc/init.d/$srvname /etc/rc2.d/S99$srvname > /dev/null
				ln -s /etc/init.d/$srvname /etc/rc3.d/S99$srvname > /dev/null
				ln -s /etc/init.d/$srvname /etc/rc4.d/S99$srvname > /dev/null
				ln -s /etc/init.d/$srvname /etc/rc5.d/S99$srvname > /dev/null
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname > /dev/null
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname > /dev/null
			fi
		;;

		fcmlb|fcpico|fcloc|fclamp)	#Foxconn gateways
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S99$srvname" ]; then
				ln -s /etc/init.d/$srvname /etc/rc2.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc3.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc4.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc5.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;

		mtac_v1.0|mtac_v1.5|mtac_refresh_v1.5|mtcap|mtcdt_ip67*|mtac)		#Multitech MTAC V1.0 SPI or V1.5 SPI + MTCAP V1.5 SPI / mtac is a fallback mechanism in case of failure of LoRa MCARD detection
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S99$srvname" ]
			then
				ln -s /etc/init.d/$srvname /etc/rc2.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc3.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc4.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc5.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		mtac_usb_v1.0|mtac_refresh_usb_v1.0)		#Multitech V1.0 USB + Refresh V1.0 USB
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			if [ ! -f "/etc/rc2.d/S99$srvname" ]
			then
				ln -s /etc/init.d/$srvname /etc/rc2.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc3.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc4.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc5.d/S99$srvname
				ln -s /etc/init.d/$srvname /etc/rc0.d/K01$srvname
				ln -s /etc/init.d/$srvname /etc/rc6.d/K01$srvname
			fi
		;;
		oielec)	#OIelec
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			update-rc.d $srvname defaults
		;;
		gemtek) #Gemtek
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			update-rc.d $srvname defaults
		;;
		flexpico) # Flex Pico
			cat $shname | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/$srvname
			chmod +x /etc/init.d/$srvname
			# Then add the lrr service instead
			if [ ! -f "/etc/rc.d/S99$srvname" ]; then
				ln -s /etc/init.d/$srvname /etc/rc.d/S99$srvname
			fi
		;;
	esac

}

# create services from files found in $ROOTACT/lrr/services
createServices()
{
	srvdir="$ROOTACT/lrr/services"

	[ ! -d "$srvdir" ] && return

	# scan all files
	for f in $(ls $srvdir)
	do
		unset SERVICENAME SERVICESOURCE ONSYSTEM

		# ignore readme
		[ ! -f "$srvdir/$f" -o "$f" = "readme" ] && continue

		# set SERVICENAME and SERVICESOURCE
		. $srvdir/$f

		# if ONSYSTEM set, activated only if system is specified
		[ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

		# check SERVICENAME and SERVICESOURCE
		if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
		then
			echo "SERVICENAME or SERVICESOURCE not set, file '$f' ignored"
			return
		fi

		# check if SERVICESOURCE file exist
		if [ ! -f "$SERVICESOURCE" ]
		then
			echo "Can't find '$SERVICESOURCE', creation of service '$SERVICENAME' aborted"
			continue
		fi

		# create service
		echo "create service $SERVICENAME"
		installService "$SERVICESOURCE" "$SERVICENAME"
	done
}

restartServices()
{
	srvdir="$ROOTACT/lrr/services"

	[ ! -d "$srvdir" ] && return

	# scan all files
	for f in $(ls $srvdir)
	do
		unset SERVICENAME SERVICESOURCE ONSYSTEM

		# ignore readme
		[ ! -f "$srvdir/$f" -o "$f" = "readme" ] && continue

		# don't restart lrr this way
		[ ! -f "$srvdir/$f" -o "$f" = "lrr" ] && continue

		# set SERVICENAME and SERVICESOURCE
		. $srvdir/$f

		# if ONSYSTEM set, activated only if system is specified
		[ ! -z "$ONSYSTEM" -a -z "$(echo $ONSYSTEM | grep $SYSTEM)" ] && continue

		# check SERVICENAME and SERVICESOURCE
		if [ -z "$SERVICENAME" -o -z "$SERVICESOURCE" ]
		then
			echo "SERVICENAME or SERVICESOURCE not set, file '$f' ignored"
			return
		fi

		# identify service path
		case $SYSTEM in
			wirmaar|wirmana|wirmams)	#Kerlink
				srv="/user/rootfs_rw/etc/rcU.d/S90$SERVICENAME"
			;;
			ir910)		#Cisco
				srv="/mnt/apps/etc/init.d/S06init$SERVICENAME"
			;;

			ciscoms)	#Cisco lora-modem multislots
				srv="/etc/init.d/S90init$SERVICENAME"
			;;

			*)	# default
				srv="/etc/init.d/$SERVICENAME"
			;;
		esac

		# check if service file exists
		if [ ! -f "$srv" ]
		then
			echo "Can't find '$srv', can't restart service"
			continue
		fi

		echo "restart service $SERVICENAME"
		$srv restart
	done
}

doPostinstall()
{
	postdir="$ROOTACT/lrr/postinstall"

	[ ! -d "$postdir" ] && return

	# scan all files
	for f in $(ls $postdir)
	do
		post="$postdir/$f"

		# ignore readme
		[ ! -f "$post" -o "$f" = "readme" ] && continue

		# execute postinstall script
		echo "execute postinstall script $post"
		$post
	done
}

use()
{
	echo "$0 [-m usb|spi] [-x x1|x8]"
	echo "Incorrect command, default values used !"
}

#
# Main
#

# get parameters
while [ $# -gt 0 ] 
do 
	case $1 in
                -m)
                        SERIALMODE="$2"
			if [ "$SERIALMODE" != "usb" -a "$SERIALMODE" != "spi" ]
			then
				use
				SERIALMODE="spi"
			fi
                        shift
                ;;
                -x)
                        BOARDTYPE="$2"
			if [ "$BOARDTYPE" != "x1" -a "$BOARDTYPE" != "x8" ]
			then
				use
				BOARDTYPE="x1"
			fi
                        shift
                ;;
        esac
        shift
done

if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		case $(uname -n) in
			klk-lpbs*)
				export ROOTACT=/user/actility
				;;
			klk-wifc*)
				export ROOTACT=/user/actility
				;;
			*)
				export ROOTACT=/home/actility
				;;
		esac
	fi
fi

if	[ ! -z "$(uname -a | grep -i lora-modem)" ]
then
	echo	"Cisco lora-modem detected (ciscoms)"
	echo	"WARNING: you are trying to install lrr directly on the station !"
	echo	"On this device, the lrr must be installed in a lxc container"
	echo	"Run 'lxc-info -n lab' to find the ip address of the container,"
	echo	"then connect to this address and proceed to lrr installation in the container"
	echo	"Installation aborted."
	exit 0
fi

if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	0
fi

if [ -f $ROOTACT/lrr/suplog/suplog.x ]
then
chown root:root $ROOTACT/lrr/suplog/suplog.x
chmod u+s $ROOTACT/lrr/suplog/suplog.x
fi

mkdir -p $ROOTACT/usr/etc/lrr > /dev/null 2>&1

echo	"$ROOTACT used as root directory"

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

if	[ -z "$SYSTEM" ]
then
	if	[ ! -z "$(uname -a | grep -i 'Wirgrid\|Wirnet')" ]
	then
		echo	"System : kerlink/wirmav2"
		SYSTEM=wirmav2
	fi
	if	[ ! -z "$(uname -a | grep -i raspberrypi)" ]
	then
		#If this is a SPI model then there will be  /dev/spidev0.0 and /dev/spidev0.1 devices
		if	[ ! -z "$(ls /dev/spidev*)" ]
		then
			echo	"System : rbpi_v1.0"
			SYSTEM=rbpi_v1.0
		else
			echo	"System : natrbpi_usb_v1.0"
			SYSTEM=natrbpi_usb_v1.0
		fi
	fi
	if	[ ! -z "$(uname -a | grep -i Router)" ]
	then
		echo	"System : ir910"
		SYSTEM=ir910
	fi
	if	[ ! -z "$(uname -a | grep -i am335x)" ]
	then
#		As we can not distinguish fcmlb, fcloc, fcpico and fclamp with uname methode,
#		we can use hw_version value from nvram, with defaults should be
#			For Macro GW 1.0/1.5	: BST100_Rev1.4
#			For Macro GW 2.1	: BST200_Rev1.0
#			For Pico GW 1.5		: PCG020C-V2
#			For Orange Lamp		: LGW010E-V0 or F04I0xx
#			Rem: Orange Lamp is seen as a Pico GW for now
		if [ ! -z "$(nvram get hw_version | grep -i BST200)" ]; then
			echo    "System : fcloc"
			SYSTEM=fcloc
		elif [ ! -z "$(nvram get hw_version | grep -e PCG020)" ]; then
			echo	"System : fcpico"
			SYSTEM=fcpico
		elif [ ! -z "$(nvram get hw_version | grep -e LGW010 -e F04I0)" ]; then
			echo    "System : fclamp"
			SYSTEM=fclamp
		else
			echo    "System : fcmlb"
			SYSTEM=fcmlb
		fi
	fi
	#Multitech Conduit (MTCDT) - this excludes Multitech Conduit Outdoor GW (MTCDTIP)
	if	[ ! -z "$(uname -a | grep -i mtcdt)" ] && [ -z "$(mts-io-sysfs show product-id | grep -i MTCDTIP)" ]
	then
		get_multitech_conduit_hw_mcard_version
	fi
	#Multitech Conduit Outdoor (MTCDTIP)
	if	[ ! -z $(which mts-io-sysfs) ]; then
		if [ ! -z "$(mts-io-sysfs show product-id | grep -i MTCDTIP | grep -i 26)" ]
		then
			echo "Conduit Outdoor IP67 V1.5 Rev B detected (GPS)"
			SYSTEM=mtcdt_ip67
		elif [ ! -z "$(mts-io-sysfs show product-id | grep -i MTCDTIP | grep -i 27)" ]
		then
			echo "Conduit Outdoor IP67 V2.1 detected (GPS)"
			SYSTEM=mtcdt_ip67_v2.1
		fi
	fi
	#Multitech Pico (MTCAP)
	if	[ ! -z "$(uname -a | grep -i mtcap)" ]
	then
		echo	"System : mtcap"
		SYSTEM=mtcap
	fi
	if	[ ! -z "$(uname -a | grep -i klk-lpbs)" ]
	then
#		Nothing found to distinguish wirmams and wirmaar at boot time
#		echo	"System : kerlink/wirmams"
#		SYSTEM=wirmams
		echo	"System : kerlink/wirmaar"
		SYSTEM=wirmaar
	fi
	if	[ ! -z "$(uname -a | grep -i klk-wifc)" ]
	then
		echo	"System : kerlink/wirmana"
		SYSTEM=wirmana
	fi
	if	[ ! -z "$(uname -a | grep -i 'Linux lab')" ]
	then
		echo	"System : ciscoms"
		SYSTEM=ciscoms
	fi
	if	[ ! -z "$(uname -a | grep -i 'kona-micro-indoor')" ]
	then
		SYSTEM=tek_micro8
	fi
	if	[ ! -z "$(uname -a | grep -i 'Kona')" ]
	then
		get_tektelic_hw_version
	fi
	if	[ ! -z "$(uname -a | grep -i 'Linux oinet937')" ]
	then
		echo	"System : oielec"
		SYSTEM=oielec
	fi
	if      [ ! -z "$(uname -a | grep -i 'Linux OutdoorAP')" ]
	then
	        echo    "System : gemtek"
	        SYSTEM=gemtek
	fi
	# Flex Pico
	if [ ! -z "$(uname -a | grep -i 'OpenWrt')" ]; then
		SYSTEM=flexpico
	fi
    # all Tracknet
    if [ ! -z "$(uname -a | grep 'InDoor')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
    if [ ! -z "$(uname -a | grep -i 'TabsHub')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
    if [ ! -z "$(uname -a | grep -i 'MinolGW')" ]; then
        echo "System : tracknet"
        SYSTEM=tracknet
    fi
fi

if	[ -z "$SYSTEM" ]
then
	echo	"cannot find host system"
	exit	0
fi

echo	"# Generated lrr configuration file ($(date))" > $ROOTACT/usr/etc/lrr/_parameters.sh
echo	"SYSTEM=${SYSTEM}" >> $ROOTACT/usr/etc/lrr/_parameters.sh

echo	"System : $SYSTEM"
export SYSTEM

date > $ROOTACT/usr/etc/lrr/sysconfig_done

#wirgrid=$(uname -a | grep -i Wirgrid)
#if	[ -z "$wirgrid" ]
#then
#	echo	"System is not a kerlink/wirma/wirgrid : no configuration"
#	exit	0
#fi

#
# add following lines in /etc/profile if not present
#
if [ "$SYSTEM" != "wirmams" -a "$SYSTEM" != "wirmaar" -a "$SYSTEM" != "wirmana"  -a "$SYSTEM" != "linux-x86" -a "$SYSTEM" != "linux-x86_64" ]
then
	PROF_LINE="export ROOTACT=${ROOTACT}"
	PATH_LINE="export PATH=\$PATH:\$ROOTACT/lrr/com"
	ALIA_LINE="alias cdr='cd \$ROOTACT'"
	line=$(grep "$PROF_LINE" $INIT_PROF)
	if	[ -z "$line" ]
	then
		echo	"ROOTACT not present in $INIT_PROF : add it"
		echo	>> $INIT_PROF
		echo	$PROF_LINE >> $INIT_PROF
		echo	$PATH_LINE >> $INIT_PROF
		echo	$ALIA_LINE >> $INIT_PROF
		echo "alias l='ls --color=auto'" >> $INIT_PROF
		echo "alias ll='ls -l --color=auto'" >> $INIT_PROF
	else
		echo	"ROOTACT already present in $INIT_PROF"
	fi
else
	echo	"Do not change /etc/profile on target $SYSTEM"
fi

# force INIT_FILE because it will be removed from configuration file
# and it has always been /etc/profile
INIT_FILE=/etc/inittab
if	[ -f $INIT_FILE ]
then
#
# remove following line from /etc/inittab if present
#
#"lr:X:respawn:$ROOTACT/lrr/com/initlrr.sh -s inittab"

	line=$(grep "initlrr.sh" $INIT_FILE)
	if	[ ! -z "$line" ]
	then
		echo	"remove initlrr.sh line from $INIT_FILE"
		cp $INIT_FILE /tmp
		sed '/initlrr.sh/d' /tmp/$(basename $INIT_FILE) > $INIT_FILE
	fi
fi

case $SYSTEM in
	wirmav2)	#Kerlink
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
		checkSupportUser
		addIptables_wirmav2
	;;
	wirmams)	#Kerlink
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=ms" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/rcU.d/S90lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh

		createServices
		checkSupportUserWirmaMS
		addIptables_wirmams
	;;
	wirmaar)	#Kerlink
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x8" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/rcU.d/S90lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
		checkSupportUserWirmaAR
		addIptables_wirmaar
        addHwDetection_wirmaar
		mkdir -p /user/rootfs_rw/etc/profile.d
		cp /user/actility/lrr/envlrr /user/rootfs_rw/etc/profile.d/envlrr
	;;
	wirmana)	#Kerlink
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/rcU.d/S90lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
		checkSupportUserWirmaNA
		addIptables_wirmana
	;;
	rbpi_v1.0)	#RaspBerry SPI V1.0
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	natrbpi_usb_v1.0)	#RaspBerry USB V1.0
		echo "SERIALMODE=usb" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	ir910)		#Cisco
		echo "SERIALMODE=usb" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/mnt/apps/etc/init.d/S06initlrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;

	ciscoms)	#Cisco lora-modem multislots
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x8" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/S90initlrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
		cat $ROOTACT/lrr/com/cmd_shells/ciscoms/iptables.sh > /etc/init.d/S48iptables
		chmod +x /etc/init.d/S48iptables
		cat $ROOTACT/lrr/com/cmd_shells/ciscoms/hosts_service.sh > /etc/init.d/S58hosts
		chmod +x /etc/init.d/S58hosts
		cat $ROOTACT/lrr/com/cmd_shells/ciscoms/box_setup_service.sh > /etc/init.d/S59box_setup
		chmod +x /etc/init.d/S59box_setup
		if [ ! -f "$ROOTACT/usr/etc/lrr/credentials.txt" ]
		then
            echo "# standalone" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "secret" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "username" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "password" >> $ROOTACT/usr/etc/lrr/credentials.txt
            echo "# virtual"  >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "username" >> $ROOTACT/usr/etc/lrr/credentials.txt
			echo "password" >> $ROOTACT/usr/etc/lrr/credentials.txt
		fi
		rm -rf /tmp/log
		mkdir -p /tmp/log
		mkdir -p /tmp/log/_LRRLOG
                LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
                LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
                echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
                echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
                POSTINSTDIR=$ROOTACT/usr/etc/lrr/usr_postinstall.sh
                if [ -f "$POSTINSTDIR" ]
                then
                        $POSTINSTDIR
                        rm $POSTINSTDIR
                fi

		checkSupportUserCiscoms
	;;

	tektelic|tek_macro16|tek_micro8|tek_dish64)	#Tektelic
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x8" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
		checkSupportUser
	;;

	fcmlb|fcpico|fclamp)	#Foxconn 1.0/1.5 GW
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		fcswitchpart=/usr/bin/switch_partition.sh
		if [ ! -e ${ROOTACT}/lrr/com/cmd_shells/switch_partition.sh ] && [ -f ${fcswitchpart} ]; then
			ln -s ${fcswitchpart} ${ROOTACT}/lrr/com/cmd_shells
		fi
		createServices
		disableCfgmgr
		checkSupportUser
		[ "$SYSTEM" = "fcpico" ] && addIptables
	;;

	fcloc)	#Foxconn 2.1 GW
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x8" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		fcswitchpart=/usr/bin/switch_partition.sh
		if [ ! -e ${ROOTACT}/lrr/com/cmd_shells/switch_partition.sh ] && [ -f ${fcswitchpart} ]; then
			ln -s ${fcswitchpart} ${ROOTACT}/lrr/com/cmd_shells
		fi
		createServices
		checkSupportUser
	;;

    #Multitech MTAC V1.0 SPI or V1.5 SPI + MTCAP V1.5 SPI +MTCDT IP67 models / mtac is a fallback mechanism in case of failure of LoRa MCARD detection
	mtac_v1.0|mtac_v1.5|mtac_refresh_v1.5|mtcap|mtcdt_ip67|mtac|mtcdt_ip67_v2.1)
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	mtac_usb_v1.0|mtac_refresh_usb_v1.0)		#Multitech V1.0 USB
		echo "SERIALMODE=usb" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		createServices
	;;
	oielec)	#OIelec
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
		chmod +x /etc/init.d/lrr
		update-rc.d lrr defaults
		createServices
		checkSupportUser
	;;
	gemtek) #Gemtek
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
                LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
                echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
                echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
                createServices
		checkSupportUserGemtek
		useBashInteadOfDash
	;;
	flexpico) # Flex Pico
		echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		# Remove original factory lora service (lora_pkt_fwd, a simple pkt_forwarder) and disable its monitoring
		if [ -f "/etc/rc.d/S94lora" ]; then
			sed -i 's/^lora_pmon/#lora_pmon/' /etc/rc.local
			kill $(ps | grep lora_pmon | grep -v grep | awk -F " " '{print $1}')
			/etc/init.d/lora stop
			/etc/init.d/lora disable
		fi
		createServices
		checkSupportUser
	;;
    tracknet)

        echo "SERIALMODE=spi" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
        cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
        chmod +x /etc/init.d/lrr
        cat > /etc/init.d/lrrs <<EOF
#!/bin/sh /etc/rc.common

START=99
STOP=99

start() {
    logger -s -p info -t "[ACT]" "Starting Actility LRR service."
   /etc/init.d/lrr start
}

stop() {
    logger -s -p info -t "[ACT]" "Stopping Actility LRR service."i
   /etc/init.d/lrr stop
}

EOF
        chmod +x /etc/init.d/lrrs
        if [ ! -f "/etc/rc.d/S99lrrs" ]
        then
            ln -s /etc/init.d/lrr /etc/rc.d/S99lrrs > /dev/null
        fi

        # custom antenna gain configuration
        #cat > $ROOTACT/usr/etc/lrr/custom.ini <<EOF
#[antenna:0]
#    cableloss=1.0
#    gain=3.0
#EOF
 
        checkSupportUserTracknet
        LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o) 
        LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u) 
        echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh 
        echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh            
        ;;

	linux-x86|linux-x86_64) #linux 32.64 bits generic with semtech pico via tty
		echo "SERIALMODE=tty" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "BOARDTYPE=x1" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "SERVICELRR=/etc/init.d/lrr" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		LRROUI=$($ROOTACT/lrr/com/shells/getid.sh -o)
		LRRGID=$($ROOTACT/lrr/com/shells/getid.sh -u)
		echo "LRROUI=$LRROUI" >> $ROOTACT/usr/etc/lrr/_parameters.sh
		echo "LRRGID=$LRRGID" >> $ROOTACT/usr/etc/lrr/_parameters.sh
#		cat $ROOTACT/lrr/com/lrrservice.sh | sed "s?_REPLACEWITHROOTACT_?$ROOTACT?" > /etc/init.d/lrr
#		chmod +x /etc/init.d/lrr
#		update-rc.d lrr defaults

		echo "Do not create user support on target $SYSTEM"
		echo "Do not create service LRR on targe $SYSTEM"
	;;

esac

if [ "$SYSTEM" != "linux-x86" -a "$SYSTEM" != "linux-x86_64" ]
then
	doPostinstall
	restartServices
fi

echo	"System configuration done"

exit	0
