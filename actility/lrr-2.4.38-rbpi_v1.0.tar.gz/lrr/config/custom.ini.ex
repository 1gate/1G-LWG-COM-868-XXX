;
;	this is an example of some custom parameters
;

[board:0]
	aeskey=595EB592055421C06895E4D4CE0FE63D

[board:1]
	aeskey=ED63A6F6DC9240305680D2DDBFAD956B

[antenna:0]
	gain=3
	cablelost=1

[antenna:1]
	gain=6
	cablelost=3

[antenna:2]
	gain=0
	cablelost=0
