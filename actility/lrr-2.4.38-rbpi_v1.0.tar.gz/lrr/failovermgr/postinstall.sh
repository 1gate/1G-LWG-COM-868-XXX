#!/bin/sh

if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		case $(uname -n) in
			klk-lpbs*)
				export ROOTACT=/user/actility
				;;
			klk-wifc*)
				export ROOTACT=/user/actility
				;;
			*)
				export ROOTACT=/home/actility
				;;
		esac
	fi
fi

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi

[ -f $ROOTACT/lrr/com/_functions.sh ] && . $ROOTACT/lrr/com/_functions.sh

# If not active (lrr.ini:[services].ipfailover=1) just do nothing
# A ipfailover restart is required to reread configuration
active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services ipfailover)
[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services ipfailover)

if [ "$active" != "1" ]
then
	echo "Service ipfailover disabled. If enabled later you must run sysconfiglrr.sh again."
	exit 1
fi

[ -f "$ROOTACT/lrr/failovermgr/$SYSTEM/postinstall.sh" ] && $ROOTACT/lrr/failovermgr/$SYSTEM/postinstall.sh
