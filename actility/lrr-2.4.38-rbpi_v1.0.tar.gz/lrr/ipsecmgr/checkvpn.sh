#!/bin/sh
#
#   checkvpn.sh
#
#   Monitor VPN state:
#   - look for a process named charon. Execute "ipsec start" if missing
#   - check state of the connections. Execute "ipsec stop" + "ipsec start" if state is not ESTABLISHED

exec 2> /dev/null

source $ROOTACT/usr/etc/lrr/_parameters.sh
source $ROOTACT/lrr/com/_functions.sh

case "$SYSTEM" in
	fcpico)
		LSTCNX="lrc1"
		;;
	*)
		LSTCNX="lrc1 lrc2"
		;;
esac

VERSION="1.0.8"

# Commands & configuration
system=$(uname -n)
case "$system" in
	klk-lpbs*)
		CMDVPN="/user/strongswan/usr/local/cortexa9hf-vfp-neon-poky-linux-gnueabi/sbin/ipsec"
		CONFIGFILE="/user/strongswan/usr/local/etc/ipsec.conf"
		export PATH="$PATH:/user/actility/lrr/com/"
		LOCAL_ETC="/user/strongswan/usr/local/etc"
		;;
	Wirnet*)
		CMDVPN="/usr/sbin/ipsec"
		LOCAL_ETC="/etc"
		CONFIGFILE="$LOCAL_ETC/ipsec.conf"
		export PATH="/mnt/fsuser-1/actility/lrr/sftp:$PATH:/mnt/fsuser-1/actility/lrr/com/"
		;;
	am335*)
		LOCAL_ETC="/usr/local/strongswan/etc"
		CMDVPN="/usr/local/strongswan/arm-linux-gnueabihf/sbin/ipsec"
		CONFIGFILE="/usr/local/strongswan/etc/ipsec.conf"
		export PATH="$PATH:/home/actility/lrr/com/:/home/actility/lrr/sftp/"
		export LD_LIBRARY_PATH="/usr/local/strongswan/lib/ipsec:/usr/local/strongswan/arm-linux-gnueabihf/lib"
		;;
	fcpico*)
		LOCAL_ETC="/usr/local/strongswan/etc"
		CMDVPN="/usr/local/strongswan/arm-linux-gnueabihf/sbin/ipsec"
		CONFIGFILE="/usr/local/strongswan/etc/ipsec.conf"
		export PATH="$PATH:/home/actility/lrr/com/:/home/actility/lrr/sftp/"
		export LD_LIBRARY_PATH="/usr/local/strongswan/lib/ipsec:/usr/local/strongswan/arm-linux-gnueabihf/lib"
		;;
	*)
		CMDVPN="/usr/local/arm-none-linux-gnueabi/sbin/ipsec"
		CONFIGFILE="/usr/local/etc/ipsec.conf"
		export PATH="$PATH:/mnt/fsuser-1/actility/lrr/com/"
		LOCAL_ETC="/usr/local/etc"
		;;
esac

# get LRR UUID
LRR_UUID=$(echo "$LRROUI-$LRRGID" | tr '[:lower:]' '[:upper:]')
#DECRYPTION_KEY=$(echo "pass:"; echo "$LRROUI-$LRRGID" tr '[:lower:]' '[:upper:]')
DECRYPTION_KEY=$(echo "pass:")
DECRYPTION_KEY=$DECRYPTION_KEY"$(echo "$LRROUI-$LRRGID" | tr '[:lower:]' '[:upper:]')"

INFRAINI="$LOCAL_ETC/infra.ini"
LOCAL_VPN_KEYS="$LOCAL_ETC/localkeys"
CNXCHECK="$CMDVPN status"
STARTVPN="$CMDVPN start"
STOPVPN="$CMDVPN stop"
CNXDOWN="$CMDVPN down"
CNXUP="$CMDVPN up"
LOOPWAIT=120             		# Time (seconds) between each check
MAXWAITCONFIGURING=240  		# Max time waiting in state configuring before trying a restart
MAXWAITDISCONNECTED=1800		# Max time waiting disconnected before trying to get a new configuration
LASTUP=0	  			# last time the VPN was up
LASTUP_BEFORE_NEW_CONF=$(date +%s)	# Initialization - Initial time or last time the VPN was up
VERBOSE=no

DBG_LOG() {
	if [ "$VERBOSE" = "yes" ]
	then
		if [ ! -z "$TRACEFILE" ]
		then
			echo "$1" >> $TRACEFILE
		else
			echo "$1"
		fi
	fi
}


# UpdateLrrConf
# This function is used to update SLRC addresses in ipfailover conf and lrr conf
_updateAddresses()
{
	DBG_LOG "Update slrc addresses in lrr.ini"
	lrrmgr="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh lrrmgr"
	failmgr="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh failovermgr"
	tmpfile="/tmp/_checkvpn$$"

	if [ -f "$INFRAINI" ]
	then
		slrc1=$(getIniConf $INFRAINI "laplrc:0" tls | sed s"/:.*//")
		slrc2=$(getIniConf $INFRAINI "laplrc:1" tls | sed s"/:.*//")
	else
		slrc1=$(cat $CONFIGFILE | sed 's/#.*//' | sed -n "/^conn lrc1/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
		slrc2=$(cat $CONFIGFILE | sed 's/#.*//' | sed -n "/^conn lrc2/,/^[^ \t]/p" | awk "/^[ \t]*right[ \t]*=/" | sed "s/.*=//")
	fi

	if [ ! -z "$slrc1" -o ! -z "$slrc2" ]
	then
		rm -f $tmpfile
		if [ ! -z "$slrc1" ]
		then
			echo "[netitf:0]" >> $tmpfile
			echo "	pingaddr=$slrc1" >> $tmpfile
			echo "	pingaddrsrc=@itf" >> $tmpfile
			echo "[netitf:1]" >> $tmpfile
			echo "	pingaddr=$slrc1" >> $tmpfile
			echo "	pingaddrsrc=@itf" >> $tmpfile
		elif [ ! -z "$slrc2" ]
		then
			echo "[netitf:0]" >> $tmpfile
			echo "	pingaddr=$slrc2" >> $tmpfile
			echo "	pingaddrsrc=@itf" >> $tmpfile
			echo "[netitf:1]" >> $tmpfile
			echo "	pingaddr=$slrc2" >> $tmpfile
			echo "	pingaddrsrc=@itf" >> $tmpfile
		fi
		if [ "$VERBOSE" = "yes" ]
		then
			if [ ! -z "$TRACEFILE" ]
			then
				{
				echo "File for lrr.ini:"
				cat $tmpfile
				} >> $TRACEFILE
			fi
		fi
		DBG_LOG "$lrrmgr --autocommit $tmpfile lrr.ini"
		$lrrmgr --autocommit $tmpfile lrr.ini
	fi
	rm -f $tmpfile

	DBG_LOG "Update slrc addresses in ipfailover.ini"
	if [ ! -z "$slrc1" -o ! -z "$slrc2" ]
	then
		echo "{" >> $tmpfile
		echo "	\"ipfailover\": {" >> $tmpfile
		echo "		\"ints\": [" >> $tmpfile
		if [ ! -z "$slrc1" ]
		then
			echo "		{" >> $tmpfile
			echo "			\"status\": \"primary\"," >> $tmpfile
			echo "			\"icmpdests\": [" >> $tmpfile
			echo "				\"$slrc1 $slrc2\"" >> $tmpfile
			echo "			]" >> $tmpfile
			if [ ! -z "$slrc2" ]
			then
				echo "		}," >> $tmpfile
			else
				echo "		}" >> $tmpfile
			fi
		fi
		if [ ! -z "$slrc2" ]
		then
			echo "		{" >> $tmpfile
			echo "			\"status\": \"secondary\"," >> $tmpfile
			echo "			\"icmpdests\": [" >> $tmpfile
			echo "				\"$slrc1 $slrc2\"" >> $tmpfile
			echo "			]" >> $tmpfile
			echo "		}" >> $tmpfile
		fi
		echo "		]" >> $tmpfile
		echo "	}" >> $tmpfile
		echo "}" >> $tmpfile
		if [ "$VERBOSE" = "yes" ]
		then
			if [ ! -z "$TRACEFILE" ]
			then
				{
				echo "File for ipfailover.ini:"
				cat $tmpfile
				} >> $TRACEFILE
			fi
		fi
		DBG_LOG "$failmgr --autocommit < $tmpfile"
		$failmgr --autocommit < $tmpfile
	fi
	rm -f $tmpfile
}

# Check VPN state with ipsec command
# return best state: 0=down, 1=connecting, 2=up
CheckVpnCnx()
{
    DBG_LOG "Check VPN connections"
    beststate=0
    for cnx in $LSTCNX
    do
        res=$($CNXCHECK $cnx)
        DBG_LOG "$cnx >>>>> $res"
        if [ -z "$res" ]
        then
            DBG_LOG "$cnx: down"
            $CNXDOWN $cnx
            $CNXUP $cnx
            beststate=1
            continue
        fi
        res2=$(echo "$res" | grep INSTALLED)
        if [ ! -z "$res2" ]
        then
                DBG_LOG "$cnx: up"
                [ $beststate -lt 2 ] && beststate=2
                LASTUP=$(date +%s)
		LASTUP_BEFORE_NEW_CONF=$(date +%s)
                continue
        fi
        res2=$(echo "$res" | grep CONNECTING)
        if [ ! -z "$res2" ]
        then
                echo "$cnx: connecting"
                [ $beststate -lt 1 ] && beststate=1
                continue
        fi
        res2=$(echo "$res" | grep "no match")
        if [ ! -z "$res2" ]
        then
            echo "$cnx: down"
            echo "$CNXDOWN $cnx"
            $CNXDOWN $cnx
            echo "$CNXUP $cnx"
            $CNXUP $cnx
            beststate=1
            continue
        fi
        DBG_LOG "$cnx: ???"
    done
    return $beststate

}

# Check if VPN is configured
CheckVpnConfigured()
{
    DBG_LOG "Check VPN configuration"

    if [ ! -f "$CMDVPN" ]
    then
        DBG_LOG "vpn not installed"
        return 1
    fi
      
    res=$(grep lrc $CONFIGFILE)
    if [ -z "$res" ]
    then
        DBG_LOG "vpn not configured in ${CONFIGFILE}"
        return 1
    else
        DBG_LOG "vpn configured"
        return 0
    fi
}

# Check if VPN process charon is running
CheckVpnProcess()
{
    DBG_LOG "Check VPN process"
    
    if [ ! -z $(pidof starter) ] && [ ! -z $(pidof charon) ]
    then
            DBG_LOG "vpn process: ok"
            return 0
    else
        DBG_LOG "vpn process: error"
        return 1
    fi
}

# Get initial local VPN keys
GetLocalVpnKeys()
{
    if [ [ -z "$LOCAL_VPN_KEYS" ] || [ ! -f "$LOCAL_VPN_KEYS" ] ]
    then
        return 1
    fi

    DBG_LOG "Getting local VPN keys"

    # create directories and copy files
    IPSEC_D="$LOCAL_ETC/ipsec.d"
    [ ! -d "$IPSEC_D" ] && mkdir $IPSEC_D

    cp $LOCAL_VPN_KEYS/ipsec.conf $LOCAL_ETC
    cp $LOCAL_VPN_KEYS/ipsec.secrets $LOCAL_ETC
    cp $LOCAL_VPN_KEYS/strongswan.conf $LOCAL_ETC

    cp -r $LOCAL_VPN_KEYS/cacerts $IPSEC_D
    cp -r $LOCAL_VPN_KEYS/certs $IPSEC_D
    cp -r $LOCAL_VPN_KEYS/private $IPSEC_D

    [ ! -d "$IPSEC_D/acerts" ] && $IPSEC_D/acerts
    [ ! -d "$IPSEC_D/ocspcerts" ] && mkdir $IPSEC_D/ocspcerts
    [ ! -d "$IPSEC_D/crls" ] && mkdir $IPSEC_D/crls

    chmod 644 $IPSEC_D/certs/*.pem
    chmod 600 $IPSEC_D/private/*

    # update slrc addresses in lrr.ini and ipfailover.ini
    _updateAddresses

    DBG_LOG "configuration finished"
    return 0
}

# Get initial VPN keys
GetVpnKeys()
{
    DBG_LOG "Getting VPN keys"

    # start configuration
    VPN_CFG="${LOCAL_ETC}/vpn.cfg"
    if [ ! -f "$VPN_CFG" ]
        then
        if [ -z "$LOCAL_VPN_KEYS" ]
        then
            DBG_LOG "Missing download server cfg file"
        else
            # Retrieve initial local VPN keys
            GetLocalVpnKeys
        fi
        return 1
    fi

    PLATFORM=$(grep -e "PLATFORM=" $VPN_CFG | cut -d"=" -f2)
    OPERATOR=$(grep -e "OPERATOR=" $VPN_CFG | cut -d"=" -f2)
  
    SFTP=$(grep -e "SRV=" $VPN_CFG | cut -d"=" -f2)
    ID=$(grep -e "PRESTAGER=" $VPN_CFG | cut -d"=" -f2)
    KEY=$(grep -e "KEY=" $VPN_CFG | cut -d"=" -f2)
    PASS=$(grep -e "PASS=" $VPN_CFG | sed -e 's/^PASS=//')

    #CFG_TAR="LRR_${LRR_UUID}.tar.gz"
    CFG_TAR="Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}.tar.gz"
    ENC_TAR="${CFG_TAR}.enc"

    if [[ -z "$SFTP" || -z "$ID" || -z "$KEY" || -z "$PASS" ]]
    then
        DBG_LOG "Missing download server configuration"
        return 1
    fi

    USER="download${ID}"
    LOC_DIR="/tmp/secure"
    SRV_DIR="/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}"

    [ ! -d "${LOC_DIR}" ] && mkdir ${LOC_DIR}
    cd ${LOC_DIR}

    if [ "$NOENCODE" = "1" ]
    then
	    password=$PASS
    else
	    password=$(echo "$PASS" | openssl enc -aes-256-cbc -base64 -d -pass pass:"${KEY}+${ID}" | awk '{ printf $1 }')
    fi

    if [ -z "$password" ]
    then
        DBG_LOG "Wrong password!"
        return 1
    fi

    DBG_LOG "Retrieving ${SRV_DIR}/${ENC_TAR}"
            
    case "$system" in
    klk-lpbs*)
        DBG_LOG "klk-lpbs"
        sshpass.x -p "$password" sftp -o StrictHostKeyChecking=no ${USER}@${SFTP}:${SRV_DIR}/${ENC_TAR} ${LOC_DIR}/
        ;;
    *)
        DBG_LOG "others"
        sshpass.x -p "$password" sftp -y ${USER}@${SFTP}:${SRV_DIR}/${ENC_TAR} ${LOC_DIR}/
        ;;
    esac

    if [ ! -f "${ENC_TAR}" ]
    then
        DBG_LOG "Couldn't retrieve configuration files."
        return 1;
    fi

    if [ "$NOENCODE" = "1" ]
    then
	    mv ${ENC_TAR} ${CFG_TAR}
    else
	    #v1.4 version
	    openssl enc -aes-256-cbc -d -in ${ENC_TAR} -out ${CFG_TAR} -pass $DECRYPTION_KEY
    fi
    tar xvf ${CFG_TAR}
    if [ $? == 0 ]
    then
	# create directories and copy files
	IPSEC_D="$LOCAL_ETC/ipsec.d"
	[ ! -d "$IPSEC_D" ] && mkdir $IPSEC_D

	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.conf $LOCAL_ETC
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/ipsec.secrets $LOCAL_ETC
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/strongswan.conf $LOCAL_ETC
	cp $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/infra.ini     ${INFRAINI}

	cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/cacerts $IPSEC_D
	cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/certs $IPSEC_D
	cp -r $ID/Lrr_${PLATFORM}_${OPERATOR}_${LRR_UUID}/private $IPSEC_D

	[ ! -d "$IPSEC_D/acerts" ] && mkdir $IPSEC_D/acerts
	[ ! -d "$IPSEC_D/ocspcerts" ] && mkdir $IPSEC_D/ocspcerts
	[ ! -d "$IPSEC_D/crls" ] && mkdir $IPSEC_D/crls

	chmod 644 $IPSEC_D/certs/*.pem
	chmod 600 $IPSEC_D/private/*

	# update slrc addresses in lrr.ini and ipfailover.ini
	_updateAddresses

	# Push an empty file on the SFTP server, under the /done subdirectory, to indicate that the archive has been downloaded and handled correctly
	# Then, for security reasons, the SFTP server will delete the archive
	echo > ${ENC_TAR}
	case "$system" in
	klk-lpbs*)
		DBG_LOG "klk-lpbs - Ask for file deletion on the SFTP server"
		sshpass.x -p "$password" sftp -o StrictHostKeyChecking=no ${USER}@${SFTP} << EOF
                cd done
                put ${ENC_TAR}
EOF

	        ;;
	*)
        	DBG_LOG "others - Ask for file deletion on the SFTP server"
	        sshpass.x -p "$password" sftp -y ${USER}@${SFTP} << EOF
                cd done
                put ${ENC_TAR}
EOF
        	;;
	    esac

	DBG_LOG "configuration finished"
	return 0
    else
	DBG_LOG "configuration failed"
	return 1
    fi
}

# Start VPN
StartVpnProcess()
{
    DBG_LOG "Starting VPN"
    $STARTVPN
}

# Stop VPN
StopVpnProcess()
{
    DBG_LOG "Stopping VPN"
    $STOPVPN

    if [ ! -z $(pidof starter) ]
    then 
	DBG_LOG "Need to kill starter"
	kill -9 $(pidof starter)
    fi

    if [ ! -z $(pidof charon) ]
    then
	DBG_LOG "Need to kill charon"
        kill -9 $(pidof charon)
    fi
}

# Restart VPN
RestartVpnProcess()
{
    StopVpnProcess
    sleep 5
    StartVpnProcess
}

Use()
{
    echo "checkvpn.sh [-V] || [-v] start|stop"
    echo "  -v: verbose"
    echo "  -V: get version and exit"
    exit
}

StartMonitoring()
{
    while [ 1 ]
    do
        [ ! -z "$firstCall" ] && sleep $LOOPWAIT
        firstCall=no
        curDate=$(date +"%d/%m %H:%M:%S")
        DBG_LOG "$curDate Check VPN state"

        CheckVpnConfigured

        if [ $? -ne 0 ]
        then
            DBG_LOG "Not Configured"
            case "$system" in
            klk-lpbs*)
                unset LD_LIBRARY_PATH
                ;;
            *)
                ;;
            esac

            GetVpnKeys
            RestartVpnProcess

        else
            case "$system" in
            klk-lpbs*)
	            export LD_LIBRARY_PATH="/user/strongswan/usr/local/lib/ipsec:/user/strongswan/usr/local/cortexa9hf-vfp-neon-poky-linux-gnueabi/lib"
                    ;;
            *)
                    ;;
            esac

            CheckVpnProcess
            # Vpn not started
            if [ $? = 1 ]
            then
                RestartVpnProcess
                sleep 10
                continue
            fi
            CheckVpnCnx
            # best state is down
            if [ $? = 0 ]
            then
                DBG_LOG "Vpn down, restart"
                RestartVpnProcess
                continue
            # best state is connecting
            elif [ $? = 1 ]
            then
            	now=$(date +%s)
                restartTime=$(($LASTUP + $MAXWAITCONFIGURING))
                if [ $restartTime -lt $now ]
                then
                	LASTUP=$(date +%s)
                        echo "In state connecting for more than $MAXWAITCONFIGURING seconds, restart"
                        CheckVpnCnx
                fi
            fi
	   
	    # If the gateway has a configuration and cannot be connected for $MAXWAITDISCONNECTED, try to retrieve a new conf 
	    now=$(date +%s)
	    newConfTime=$(($LASTUP_BEFORE_NEW_CONF + $MAXWAITDISCONNECTED))
	    if [ $newConfTime -lt $now ]
	    then
		GetVpnKeys
		LASTUP_BEFORE_NEW_CONF=$(date +%s)
		RestartVpnProcess
	    fi		    

        fi
    done
}


#
#       MAIN
#

while [ $# -gt 0 ]
do
        case "$1" in
                "-V")
                        echo "$VERSION"
                        exit
                        ;;
                "-v")
                        VERBOSE="yes"
                        shift
                        ;;
                "start")
                        shift
                        ;;
                "stop")
			StopVpnProcess
                        killall checkvpn.sh
                        shift
                        ;;
                *)
                        echo "Unknown option '$1' !"
                        Use
                        shift
                        ;;
        esac
done

NOENCODE="$(getIniConf $ROOTACT/usr/etc/lrr/checkvpn.ini checkvpn distarencode)"
verbose=$(getIniConf $ROOTACT/usr/etc/lrr/checkvpn.ini checkvpn tracelvl)
if [ ! -z "$verbose" -a "$verbose" != "0" ]
then
	VERBOSE="yes"
	TRACEFILE="$ROOTACT/var/log/lrr/checkvpn.log"
	DBG_LOG "################## START $(date) ################"
fi

# If not active (lrr.ini:[services].checkvpn2=1) just do nothing
# A checkvpn restart is required to reread configuration
active=$(getIniConf $ROOTACT/usr/etc/lrr/lrr.ini services checkvpn2)
[ $? = 0 ] && active=$(getIniConf $ROOTACT/lrr/config/lrr.ini services checkvpn2)

if [ "$active" != "1" ]
then
	DBG_LOG "checkvpn2 unactivated, doing nothing ..."
	while true
	do
		sleep 3600
	done
	exit 1
fi

StartMonitoring

