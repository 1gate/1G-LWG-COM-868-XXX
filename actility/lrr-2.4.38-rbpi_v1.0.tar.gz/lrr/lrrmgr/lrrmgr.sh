#!/bin/bash

#
#	lrrmgr
#
# --get: get configuration from lrr.ini
# --apply: set configuration in lrr.ini. Save previous config in rollback.ini if it doesn't exist
# --commit: remove existing rollback.ini and create a new one with actual configuration
# --rollback: restore configuration saved in rollback.ini

if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		export ROOTACT=/home/actility
	fi
fi

ROLLDIR=$ROOTACT/usr/data/lrr/lrrmgr/
PREFIX=lrrmgr_
CUSTOMDIR=$ROOTACT/usr/etc/lrr
DEFAULTDIR=$ROOTACT/lrr/config
TMPFILE=/tmp/_lrrmgr$$
MICMD="$ROOTACT/lrr/moreini/moreini.x -e"
REMOVEKEY="__TOBEREMOVED__"

use()
{
	echo "Use: $0 --get [--default] <file> | --apply <file> <target> | --rollback | --commit"
	echo "  --get [--default] <file>: get custom ini file <file>. If --default is used,"
	echo "    it's not the custom but the default configuration file that is returned"
	echo "  --apply <file> <target>: merge .ini <file> into <target>"
	echo "  --rollback: restore previous files"
	echo "  --commit: commit current configuration (=remove rollback files)"
	echo "  --autocommit: apply on config file + rollback file, no commit needed"
}

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

echo "$0 $*" >&2
if [ "$1" = "--get" ]
then
	# --get: get configuration from <file>.ini
	shift
	## --default ?
	if [ "$1" == "--default" ]
	then
		dir="$DEFAULTDIR"
		shift
	else
		dir="$CUSTOMDIR"
	fi

	if [ -z "$1" ] 
	then
		echo "Missing file name !"
		use
		exit 1
	fi

	dn=$(dirname $1)
	if [ ! -z "$dn" -a "$dn" != "." ]
	then
		echo "Incorrect filename '$1', give a file name without path"
		exit 1
	fi

	file="$dir/$1"
	[ -f "$file" ] && cat $file
	exit 0
elif [ "$1" = "--apply" -o "$1" = "--autocommit" ]
then
	# --apply: set configuration in <file>.ini. Save previous config in lrrmgr_<file>.ini if it doesn't exist
	# --autocommit: apply on lrr.in and rollback lrrmgr_*.ini
	[ "$1" = "--autocommit" ] &&  autocommit="1"

	shift
	file="$1"	# file to merge in .inI
	target="$2"	# target .ini file
	if [ -z "$target" ]
	then
		echo "Missing <target> filename"
		use
		exit 1
	fi

	[ ! -f "$file" ] && exit 1

	[ ! -d "$ROLLDIR" ] && mkdir -p "$ROLLDIR"

	rollfile="lrrmgr_$target"

	# if rollfile doesn't exist, save actual file
	if [ ! -f "$ROLLDIR/$rollfile" -a "$autocommit" != "1" ]
	then
		if [ -f "$CUSTOMDIR/$target" ]
		then
			echo "cp $CUSTOMDIR/$target $ROLLDIR/$rollfile" 1>&2
			cp $CUSTOMDIR/$target $ROLLDIR/$rollfile
		else
			# file doesn't exist => save an emtpy file to make a correct rollback
			echo "touch $ROLLDIR/$rollfile" 1>&2
			touch $ROLLDIR/$rollfile
		fi
	elif [ -f "$ROLLDIR/$rollfile" -a "$autocommit" = "1" ]
	then
		# autocommit: apply also on rollback file
		echo "$MICMD -t $ROLLDIR/$rollfile -y -a $file" 1>&2
		$MICMD -t $ROLLDIR/$rollfile -y -a $file
	fi

	echo "$MICMD -t $CUSTOMDIR/$target -y -a $file" 1>&2
	$MICMD -t $CUSTOMDIR/$target -y -a $file

	exit 0
elif [ "$1" = "--rollback" ]
then
	# --rollback: restore configuration saved in lrrmgr_*.ini
	lst=$(ls $ROLLDIR/${PREFIX}* 2>/dev/null)
	for f in $lst
	do
		name=$(echo $f | sed "s?.*/$PREFIX??")
		if [ -s "$f" ]
		then
			echo "mv $f $CUSTOMDIR/$name" 1>&2
			mv $f $CUSTOMDIR/$name
		else
			# if rollback file is empty that mean the file didn't exist
			echo "rm $CUSTOMDIR/$name" 1>&2
			rm $CUSTOMDIR/$name
		fi
		echo "rm -f $f" 1>&2
		rm -f "$f"
	done
	exit 0
elif [ "$1" = "--commit" ]
then
	# --commit: remove existing lrrmgr_*.ini
	echo "rm -f $ROLLDIR/${PREFIX}*" 1>&2
	rm -f $ROLLDIR/${PREFIX}*
	exit 0
else
	echo "bad option !"
	use
	exit 1
fi

