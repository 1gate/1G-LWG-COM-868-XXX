#!/bin/sh
#
#	backup.sh
#
#	Save all lrr files, binaries and configuration, and some other
#	files needed to restore the connectivity with the lrc
#

# set $ROOTACT
if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		case $(uname -n) in
			klk-lpbs*)
				export ROOTACT=/user/actility
				;;
			klk-wifc*)
				export ROOTACT=/user/actility
				;;
			*)
				export ROOTACT=/home/actility
				;;
		esac
	fi
fi

if [ -f "$ROOTACT/usr/etc/lrr/_parameters.sh" ]
then
	. $ROOTACT/usr/etc/lrr/_parameters.sh
fi

CONF="$ROOTACT/lrr/restoremgr/$SYSTEM/conf"
if [ ! -f "$CONF" ]
then
	echo "Can't find configuration for backup, abort !"
	exit 1
fi

. "$CONF"

# check if $ROOTACT directory exists
if	[ ! -d "$ROOTACT" ]
then
	echo	"$ROOTACT does not exist"
	exit	1
fi


VERSION=$(cat $ROOTACT/lrr/Version)
DATE=$(date +%FT%T%z)
tm=$(expr $DATE : '\(.*\)+.*')
tz=$(expr $DATE : '.*+\(.*\)')
hh=$(expr $tz : '\([0-9][0-9]\)[0-9][0-9]')
mm=$(expr $tz : '[0-9][0-9]\([0-9][0-9]\)')
DATE=${tm}.0+${hh}:${mm}

echo "Preparing files for backup, please wait"

# create tar file
[ -f "/tmp/$TARFILE" ] && rm "/tmp/$TARFILE"
echo "tar czf /tmp/$TARFILE $LRRDIR $LRRCONF $LRRDATA $SUPDIR $SYSTEMFILES" >&2
tar czf /tmp/$TARFILE $LRRDIR $LRRCONF $LRRDATA $SUPDIR $SYSTEMFILES
ret=$?

# check tar file
if [ "$ret" = "0" ]
then
	tar tzf /tmp/$TARFILE >/dev/null 2>&1
	ret=$?
fi

if [ "$ret" != "0" ]
then
	echo "Failed to create a valid /tmp/$TARFILE ! COMMAND ABORTED"
	rm -f /tmp/$TARFILE
	exit	1
fi

# copy file in backup directory
[ ! -d "$BACKUPDIR" ] && mkdir -p "$BACKUPDIR"

mv /tmp/$TARFILE $BACKUPDIR
if [ $? = 0 ]
then
	# create file containing backup infos
	{
	echo -e "{\n\"restore\": {"
	echo "  \"backupLrrVersion\": \"$VERSION\","
	echo "  \"backupDate\": \"$DATE\","
	echo "  \"backupLogFile\": \"$BACKUPLOGFILE\""
	echo -e "}\n}"
	} > $BACKUPINFO
else
	echo "Failed to store backup file in backup directory (no space left ?) ! COMMAND ABORTED"
	rm -f /tmp/$TARFILE
	exit	1
fi

#
# some other packages need to add some tarbal ?
#

lst=$(ls ${ROOTACT}/usr/etc/lrr/restoremgr/*.sh 2>/dev/null)
for i in $lst
do
	echo	"add other pkg to backup from $i"
	sh ${i} > /dev/null 2>&1
done

echo "backup done"
exit $?
