#!/bin/bash

#
#	restoremgr
#
#	--get : get informations about the actual backup"
#	--backup : save current environment in backup zone"
#	--restore : restore backup as active environment"
#

if	[ -z "$ROOTACT" ]
then
	if	[ -d /mnt/fsuser-1/actility ]
	then
		export ROOTACT=/mnt/fsuser-1/actility
	else
		export ROOTACT=/home/actility
	fi
fi

ROLLDIR=$ROOTACT/usr/data/lrr/restoremgr/
RESULTFILE="/tmp/restoremgr.result"

use()
{
	echo "Use: $0 --get | --backup | --restore"
	echo "  --get : get informations about the actual backup"
	echo "  --backup : save current environment in backup zone"
	echo "  --restore : restore backup as active environment"
}

createResult()
{
	{
		echo "{"
		if [ "$1" = "0" ]
		then
			echo "\"success\": true,"
		else
			echo "\"success\": false,"
		fi
		echo "\"error\": \"$2\""
		echo "}"
	} > $RESULTFILE
}

if [ -f ${ROOTACT}/lrr/com/_parameters.sh ]
then
	. ${ROOTACT}/lrr/com/_parameters.sh
fi
if [ -f ${ROOTACT}/lrr/com/_functions.sh ]
then
	. ${ROOTACT}/lrr/com/_functions.sh
fi

# Check if nfr920 is active
nfr920=$(getIniConf "$ROOTACT/usr/etc/lrr/lrr.ini" "suplog" "nfr920")
[ -z "$nfr920" ] && nfr920=$(getIniConf "$ROOTACT/lrr/config/lrr.ini" "$SYSTEM/suplog" "nfr920")
if [ "$nfr920" != "1" ]
then
	echo "nfr920 is not active => restoremgr is disabled. Aborted."
	return 1
fi

conf="$ROOTACT/lrr/restoremgr/$SYSTEM/conf"
[ -f "$conf" ] && . "$conf"

if [ "$1" = "--get" ]
then
	# used to mount the device where the backup file is stored
	type preGet >/dev/null 2>&1
	[ $? -eq 0 ] && preGet

	if [ -f "$BACKUPINFO" ]
	then
		cat "$BACKUPINFO" | grep "backup" | sed "s/,$//" | sed "s/\"//g"
	else
		echo "No backup informations found"
	fi

	# used to umount the device where the backup file is stored
	type postGet >/dev/null 2>&1
	[ $? -eq 0 ] && postGet


elif [ "$1" = "--backup" ]
then
	{
	echo "$0 $*" >&2
	ret=0
	type preBackup >/dev/null 2>&1
	[ $? -eq 0 ] && preBackup

	msg=""
	backup="$ROOTACT/lrr/restoremgr/backup.sh"
	if [ -f "$backup" ]
	then
		echo "$backup $*" >&2 
		$backup $*
		ret=$?
		[ "$ret" != "0" ] && msg="Error while creating backup file"
	else
		echo "Can't find $backup !" >&2 
		ret=1
		msg="No backup file found '$BACKUPDIR/$TARFILE'"
	fi
	type postBackup >/dev/null 2>&1
	[ $? -eq 0 ] && postBackup
	
	createResult "$ret" "$msg"
	} > $BACKUPLOGFILE 2>&1

	cat $BACKUPLOGFILE
	exit $ret

elif [ "$1" = "--restore" ]
then
	echo "$0 $*"  > $BACKUPLOGFILE 2>&1

	type preRestore	>/dev/null 2>&1
	[ $? -eq 0 ] && preRestore

	ret=0
	tarfile="$BACKUPDIR/$TARFILE"
	if [ ! -f "$tarfile" ]
	then
		echo "Backup file '$tarfile' can't be found, restore aborted !" >> $BACKUPLOGFILE 2>&1
		createResult "1" "Backup file '$tarfile' can't be found, restore aborted !"
		cat $BACKUPLOGFILE 
		exit 1
	fi

	{
	msg=""
	# save current lrr in case the restore fails
	savdirext="save$(date +%Y%m%d-%H%M%S)"
	savdirlrr="$LRRDIR.$savdirext"
	savdirconf="$LRRCONF.$savdirext"
	savdirdata="$LRRDATA.$savdirext"
	if [ ! -z "$savdirlrr" -a -d "$savdirlrr" ]
	then
		rm -rf "$savdirlrr"
		rm -rf "$savdirconf"
		rm -rf "$savdirdata"
	fi
	[ -d "$LRRDIR" ] && mv "$LRRDIR" "$savdirlrr"
	[ -d "$LRRCONF" ] && mv "$LRRCONF" "$savdirconf"
	[ -d "$LRRDATA" ] && mv "$LRRDATA" "$savdirdata"

	if [ -f "$BACKUPINFO" ]
	then
		ver=$(cat "$BACKUPINFO" | grep "backupLrrVersion" | sed "s/.*: //" | sed "s/[\",]//g")
		dt=$(cat "$BACKUPINFO" | grep "backupDate" | sed "s/[^:]*: //" | sed "s/[\",]//g")
		echo "Restoring lrr version '$ver', backup from $dt ..."
	fi

	cd /
	echo "tar xvf $tarfile" >&2
	tar xvf $tarfile
	restar=$?

	# if restore failed, "restore" current version
	if [ $restar -ne 0 -o ! -f "$ROOTACT/lrr/com/lrr.x" ]
	then
		ret=1
		echo "ERROR DURING TAR EXTRACTION. RESTORE ABORTED !"
		msg="ERROR DURING TAR EXTRACTION. RESTORE ABORTED !"

		if [ -d "$savdirlrr" ]
		then
			rm -rf "$LRRDIR"
			mv "$savdirlrr" "$LRRDIR"
		fi
		if [ -d "$savdirconf" ]
		then
			rm -rf "$LRRCONF"
			mv "$savdirconf" "$LRRCONF"
		fi
		if [ -d "$savdirdata" ]
		then
			rm -rf "$LRRDATA"
			mv "$savdirdata" "$LRRDATA"
		fi

	fi

	# read conf of version installed to execute corresponding postRestore
	[ -f "$conf" ] && . "$conf"

	type postRestore >/dev/null 2>&1
	[ $? -eq 0 ] && postRestore
	[ $ret -ne 0 ] && echo " AN ERROR OCCURED, RESTORE HAS BEEN CANCELED !"

	createResult "$ret" "$msg"
	rm -rf "$savdirlrr"
	rm -rf "$savdirconf"
	rm -rf "$savdirdata"
	} >> $BACKUPLOGFILE 2>&1

	cat $BACKUPLOGFILE
	exit $ret
else
	echo "bad option !"
	use
fi
