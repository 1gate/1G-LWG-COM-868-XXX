#!/bin/bash

#	rollbackmgr.sh
#	execute all mgr with option --rollback
#	reboot if one mgr print "REBOOTNEEDED" on stdout

GWMGR="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh gwmgr"
FAILMGR="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh failovermgr"
IPSECMGR="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh ipsecmgr"
LRRMGR="$ROOTACT/lrr/com/cmd_shells/genericmgr.sh lrrmgr"
OUTFILE=$ROOTACT/var/log/lrr/rollbackmgr.log

rm -f $OUTFILE

exec > $OUTFILE 2>&1

ACTION="--rollback"

ret=0
echo "$GWMGR $ACTION"
$GWMGR $ACTION
if [ $? -ne 0 ]
then
	ret=$?
	echo "  => error"
fi

echo "$FAILMGR $ACTION"
$FAILMGR $ACTION
if [ $? -ne 0 ]
then
	ret=$?
	echo "  => error"
fi

echo "$IPSECMGR $ACTION"
$IPSECMGR $ACTION
if [ $? -ne 0 ]
then
	ret=$?
	echo "  => error"
fi

echo "$LRRMGR $ACTION"
$LRRMGR $ACTION
if [ $? -ne 0 ]
then
	ret=$?
	echo "  => error"
fi

if [ $ret -eq 0 ]
then
	echo "rollback completed successfullyi '$(date +%Y%m%d-%H%M%S)'"
else
	echo "errors occurred during rollback"
fi

res=$(grep REBOOTNEEDED $OUTFILE 2>/dev/null)

if [ ! -z "$res" ] 
then
	echo "reboot requested ..."
	reboot
fi

exit $ret
